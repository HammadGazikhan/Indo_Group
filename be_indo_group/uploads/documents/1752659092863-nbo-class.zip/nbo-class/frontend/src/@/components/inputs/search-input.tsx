import { cn } from "@/lib/utils";
import { Search } from "lucide-react";
import React from "react";

type Props = {
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
  containerClass?: string;
  placeholder?: string;
};

export const SearchInput = (props: Props) => {
  return (
    <div className={cn("relative w-full ", props.containerClass)}>
      <Search className="absolute top-1/2 left-3 -translate-y-1/2 text-base text-[#B8B8BB] size-4" />
      <input
        placeholder={props?.placeholder ? props?.placeholder : "Search"}
        {...props?.inputProps}
        type="text"
        className={cn(
          "border-[#ECECEF] border-2 rounded py-1 pr-5 pl-10 outline-none text-primary-text placeholder-[#B8B8BB] w-full",
          props?.inputProps?.className
        )}
      />
    </div>
  );
};
