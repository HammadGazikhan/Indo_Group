import { ChartLine, Home, Search, Users } from "lucide-react";
import { CiCalendar } from "react-icons/ci";
import { LuClipboardList } from "react-icons/lu";
import { BsClipboardData } from "react-icons/bs";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { Input } from "./ui/input";
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";

// Menu items.
const items = [
  {
    title: "Clients",
    url: "clients-config",
    icon: Home,
    id: 0,
  },
  {
    title: "Facilities",
    url: "facilities-config",
    icon: Home,
    id: 1,
  },
  {
    title: "Participants",
    url: "participants-config",
    icon: Users,
    id: 2,
  },
  {
    title: "Leadership Levels",
    url: "leadership-levels-config",
    icon: Users,
    id: 3,
  },
  {
    title: "Competencies",
    url: "competencies-config",
    icon: BsClipboardData,
    id: 4,
  },
  {
    title: "Assessment Configurations",
    url: "assessment-config",
    icon: Users,
    id: 5,
  },
  {
    title: "Assessors",
    url: "assessors-config",
    icon: ChartLine,
    id: 6,
  },
  {
    title: "CLASS Configuration",
    url: "class-configuration-config",
    icon: Users,
    id: 7,
  },
  {
    title: "Assessments",
    url: "assessments",
    icon: LuClipboardList,
    id: 8,
  },
  {
    title: "Schedules",
    url: "schedules",
    icon: CiCalendar,
    id: 9,
  },
];

export function AppSidebar() {
  const location = useLocation();
  const path = location.pathname.split("/")[1];

  return (
    <Sidebar className="w-[319px]">
      <SidebarContent>
        <SidebarGroup>
          <div className="flex h-12 mt-[18px] px-4 mb-2 relative">
            <Input
              className="!rounded-[8px] text-[#A5ACBA] text-sm leading-5 py-[6px] h-12"
              placeholder="Search in NBOL"
            />
            <Search className="absolute top-[34px] right-6 size-4 text-[#A5ACBA]" />
          </div>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => {
                const isSelected = path === item.url;
                return (
                  <SidebarMenuItem
                    key={item.title}
                    className={`h-[52px] flex items-center transition-all duration-200 ${
                      isSelected
                        ? "bg-[#EFF4FF] border-l-4 border-[#155EEF]"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    <SidebarMenuButton asChild>
                      <Link
                        to={item.url}
                        className="flex gap-4 h-full px-8 py-2 w-full"
                      >
                        <item.icon
                          className={`!size-7 transition-all duration-200 ${
                            isSelected ? "text-[#155EEF]" : "text-[#5F6D7E]"
                          }`}
                        />
                        <span
                          className={`text-base transition-all duration-200 ${
                            isSelected
                              ? "text-[#155EEF] font-medium"
                              : "text-[#5F6D7E]"
                          }`}
                        >
                          {item.title}
                        </span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
