import React from "react";
import { HiOutlineTrash } from "react-icons/hi2";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { axios } from "@/config/axios";
import { CustomDialog } from "./dialog";
import CustomButton from "./button";
import { queryClient } from "@/config/query-client";
import { RiDeleteBin6Line } from "react-icons/ri";

type Props = {
  endPoint: string;
  title: string;
  itemName: string;
  refetchUrl?: string[];
  customButton?: React.ReactNode;
  onSuccess?: () => void;
};

export const DeleteItem = (props: Props) => {
  const { mutate, isPending } = useMutation({
    mutationFn: (endPoint: string) => axios.delete(endPoint),
    onSuccess(data) {
      toast.success(data.data.msg);
    },
  });

  return (
    <CustomDialog
      title={props.title}
      button={
        props?.customButton ? (
          props.customButton
        ) : (
          <span className="flex gap-1 !items-center cursor-pointer text-[#E2341D]">
            <RiDeleteBin6Line className="text-[#E2341D] size-[14px]" />
            Delete
          </span>
        )
      }
      footer={({ onClose }) => (
        <div className="flex justify-end items-center gap-5">
          <CustomButton variant="outline" onClick={onClose}>
            Close
          </CustomButton>
          <CustomButton
            variant="destructive"
            disabled={isPending}
            onClick={() => {
              mutate(props.endPoint, {
                onSuccess: () => {
                  props?.onSuccess && props?.onSuccess();
                  onClose();
                  if (props.refetchUrl)
                    queryClient.refetchQueries({
                      queryKey: props.refetchUrl,
                    });
                },
              });
            }}
          >
            <span className="flex gap-1 items-center cursor-pointer text-[#ffffff]">
              <RiDeleteBin6Line className="text-[#ffffff] size-[14px]" />
              Delete
            </span>
          </CustomButton>
        </div>
      )}
    >
      <div className="text-primary-text text-md px-6 pb-5">
        Are you sure you want to delete this {props.itemName}?
      </div>
    </CustomDialog>
  );
};
