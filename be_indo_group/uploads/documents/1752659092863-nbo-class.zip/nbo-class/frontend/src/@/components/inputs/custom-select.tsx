import React from "react";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useField, useFormikContext } from "formik";
import { Label } from "../label";

const CustomSelect = ({
  placeholder,
  name = "",
  className,
  options,
  value: propValue,
  label,
  onChange,
  getOptionLabel,
  getOptionValue,
}: {
  placeholder?: string;
  name?: string;
  className?: string;
  options: any[];
  value?: any;
  label?: string;
  onChange?: (selectedItem: any) => void;
  getOptionLabel: (item: any) => string;
  getOptionValue: (item: any) => any;
}) => {
  const formik = useFormikContext();
  const isFormik = !!formik && name;
  const [localValue, setLocalValue] = React.useState(propValue || "");

  // Use Formik field if available
  const [field, , helpers] = isFormik
    ? // eslint-disable-next-line
      useField(name)
    : [{ value: "" }, null, null];
  const value = isFormik ? field.value : propValue ?? localValue;

  const handleChange = (newValue: string) => {
    const selectedItem = options.find(
      (item) => getOptionValue(item) === newValue
    );
    console.log("Selected Item:", selectedItem); // Debugging

    if (isFormik) {
      helpers?.setValue(newValue);
      helpers?.setTouched(true);
    } else {
      setLocalValue(newValue);
    }

    onChange?.(selectedItem);
  };

  return (
    <div className={label ? "flex flex-col" : ""}>
      {label && <Label>{label}</Label>}
      <Select value={value} onValueChange={handleChange}>
        <SelectTrigger
          className={`w-[180px] h-[48px] !rounded-[5px] hover:bg-blue-50 ${className}`}
        >
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            {placeholder && <SelectLabel>{placeholder}</SelectLabel>}
            {options?.map((item) => (
              <SelectItem
                key={getOptionValue(item)}
                value={getOptionValue(item)}
              >
                {getOptionLabel(item)}
              </SelectItem>
            ))}
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  );
};

export default CustomSelect;
