import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
const CustomAccordion = ({
  data,
}: {
  data: [{ title: string; description: any }];
}) => {
  return (
    <Accordion type="multiple">
      {data?.map((item: any) => {
        return (
          <AccordionItem value={item?.title}>
            <AccordionTrigger>{item?.title}</AccordionTrigger>
            <AccordionContent>{item?.description}</AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
};

export default CustomAccordion;
