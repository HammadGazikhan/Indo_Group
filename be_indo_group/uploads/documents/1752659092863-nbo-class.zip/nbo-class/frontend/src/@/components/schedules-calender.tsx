import React, { useState, useEffect } from "react";
import moment from "moment";
import { Calendar, momentLocalizer } from "react-big-calendar";
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

const ScheduleCalendar = ({
  events,
  view = "month",
}: {
  events: any[];
  view?: any;
}) => {
  const [currentView, setCurrentView] = useState(view);

  useEffect(() => {
    console.log("Events received:", events);
  }, [events]);

  const eventStyleGetter = (event: any) => {
    let style = {
      backgroundColor: event.isLunchBreak ? "#f4b860" : "#3174ad",
      // color: "white",
      borderRadius: "5px",
      // padding: "5px",
      // border: "none",
      height: "21px !important",
    };
    return { style };
  };

  return (
    <div style={{ height: "600px" }}>
      <Calendar
        localizer={localizer}
        events={events}
        defaultView={view}
        views={["month", "week", "day", "agenda"]}
        startAccessor="start"
        endAccessor="end"
        eventPropGetter={eventStyleGetter}
        onView={(newView) => setCurrentView(newView)}
        style={{ height: 600 }}
      />
    </div>
  );
};

export default ScheduleCalendar;
