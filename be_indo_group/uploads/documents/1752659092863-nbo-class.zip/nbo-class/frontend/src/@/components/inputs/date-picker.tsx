import * as React from "react";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useField } from "formik";
import { Label } from "../label";

interface DatePickerProps {
  name: string;
  label?: string;
  className?: any;
}
export function DatePicker({ name, label, className }: DatePickerProps) {
  const [field, meta, helpers] = useField(name);
  const { value } = field;
  const { setValue } = helpers;

  return (
    <div className="h-[48px] rounded-sm">
      {label && <Label>{label}</Label>}
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant={"outline"}
            className={cn(
              `w-[280px] justify-between text-left font-normal h-[48px] rounded-sm ${className}`,
              !value && "text-muted-foreground"
            )}
          >
            {value ? format(new Date(value), "PPP") : <span>Pick a date</span>}
            <CalendarIcon />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0">
          <Calendar
            mode="single"
            selected={value ? new Date(value) : undefined}
            onSelect={(date) => setValue(date ? date.toISOString() : "")}
            initialFocus
            className="h-[48px]"
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
