import { Textarea } from "@/components/ui/textarea";
import { useField } from "formik";

interface TextAreaProps {
  name: string;
}
export function CoustomTextarea({ name }: TextAreaProps) {
  const [field, meta] = useField(name);
  return <Textarea placeholder="Type your message here." {...field} />;
}
