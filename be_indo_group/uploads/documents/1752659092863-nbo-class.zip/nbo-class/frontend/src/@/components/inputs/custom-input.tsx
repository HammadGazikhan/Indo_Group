import React, { HTMLInputTypeAttribute } from "react";
import { Input } from "../ui/input";
import { Label } from "../label";
import { useField } from "formik";

const CustomInput = ({
  placeholder,
  label,
  className = "",
  required,
  type = "text",
  name,
  params,
}: {
  label?: string;
  placeholder?: string;
  className?: string;
  required?: boolean;
  type?: HTMLInputTypeAttribute;
  name: string;
  params?: any;
}) => {
  const [field, meta] = useField(name);

  return (
    <div className="flex flex-col">
      {label && <Label required={required}>{label}</Label>}
      <Input
        {...field} // ✅ Controlled by Formik
        {...params}
        type={type}
        placeholder={placeholder}
        className={className}
      />
      {meta.touched && meta.error && (
        <div className="text-red-500 text-sm">{meta.error}</div>
      )}
    </div>
  );
};

export default CustomInput;
