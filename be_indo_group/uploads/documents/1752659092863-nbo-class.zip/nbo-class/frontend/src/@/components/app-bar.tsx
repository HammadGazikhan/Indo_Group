import React from "react";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Bell } from "lucide-react";

const AppBar = () => {
  return (
    <div className="!h-[60px] z-10 fixed w-full   border-[#DAE0E6] border-b-[1.33px]">
      <div className="w-full h-full flex justify-end gap-5 items-center px-4">
        {/* <Bell className="h-8 w-8 rotate-45" /> */}
        <img src="./icons/_Icon_.svg" className="h-8 w-8"></img>
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 ">
            <AvatarFallback className="bg-[#2B952B] text-white font-medium">
              CN
            </AvatarFallback>
          </Avatar>
          <p className="text-[10px] font-medium">Heloo</p>
        </div>
      </div>
    </div>
  );
};

export default AppBar;
