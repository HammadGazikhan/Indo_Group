import React, {
  ReactNode,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  ColumnDef,
  PaginationState,
  RowData,
  flexRender,
  getCoreRowModel,
  getExpandedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { keepPreviousData, useMutation } from "@tanstack/react-query";
import Axios from "axios";
import { toast } from "sonner";
import { FilterColumnInterface } from "@/interfaces/data-grid";
import { queryClient } from "@/config/query-client";
import { ResponseInterface } from "@/interfaces/base";
import { axios } from "@/config/axios";
import CustomButton from "@/components/button";
import {
  TiArrowSortedDown,
  TiArrowSortedUp,
  TiArrowUnsorted,
} from "react-icons/ti";

import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "../pagination";
import { cn } from "@/lib/utils";
import { SearchInput } from "@/components/inputs/search-input";
import { ApplyFilter } from "./apply-filter";
import CustomSelect from "@/components/inputs/custom-select";
import { useQuery } from "@/hooks/useQuerry";
type Props = {
  data?: any[];
  url?: string;
  tableMetaDataKey?: string;
  editable?: boolean;
  disableFilters?: boolean;
  disableSearch?: boolean;
  disablePagination?: boolean;
  columns: ColumnDef<any>[];
  extraButtons?: ReactNode;
  excelDownload?: boolean;
  enableMultiRowSelection?: boolean;
  setRowSelection?: React.Dispatch<React.SetStateAction<any>>;
  setSelectedId?: React.Dispatch<React.SetStateAction<any>>;
  onRowChange?: (
    rows: any[],
    rowIndex: number,
    column: string,
    value: any,
    keyID?: any
  ) => any[];
  globalSearchText?: string;
};

declare module "@tanstack/react-table" {
  interface TableMeta<TData extends RowData> {
    updateData: (
      rowIndex: number,
      columnId: string,
      value: unknown,
      keyID?: any
    ) => void;
  }
}

function useSkipper() {
  const shouldSkipRef = useRef(true);
  const shouldSkip = shouldSkipRef.current;

  // Wrap a function with this to skip a pagination reset temporarily
  const skip = useCallback(() => {
    shouldSkipRef.current = false;
  }, []);

  useEffect(() => {
    shouldSkipRef.current = true;
  });

  return [shouldSkip, skip] as const;
}

export const Datagrid = ({
  data,
  columns,
  extraButtons,
  url,
  onRowChange,
  tableMetaDataKey,
  disablePagination,
  disableFilters,
  disableSearch,
  excelDownload,
  setSelectedId,
  globalSearchText,
  setRowSelection,
}: Props) => {
  let perfrences: any = JSON.parse(localStorage.getItem("user_pref")!);
  let tableMetaData: any = {};
  if (tableMetaDataKey && perfrences) {
    tableMetaData = perfrences?.tableMetaData?.[tableMetaDataKey];
  }
  const [globalFilter, setGlobalFilter] = useState("");
  const [tableData, setTableData] = useState<any>({ count: 0, rows: [] });
  const [filters, setFilters] = useState<FilterColumnInterface[]>(
    tableMetaData?.filters || []
  );
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: tableMetaData?.pageIndex || 0,
    pageSize: tableMetaData?.pageSize || 10,
  });

  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = Math.ceil(tableData?.count / 10);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const pageLinks = [];
  for (let i = 1; i <= totalPages; i++) {
    pageLinks.push(i);
  }
  useEffect(() => {
    if (globalSearchText !== undefined) {
      setGlobalFilter(globalSearchText);
    }
  }, [globalSearchText]);

  const [autoResetPageIndex, skipAutoResetPageIndex] = useSkipper();

  const table = useReactTable({
    data: tableData?.rows || [],
    columns,
    defaultColumn: {
      minSize: 200,
    },

    state: {
      pagination: !disablePagination ? pagination : undefined,
      globalFilter,

      // sorting: [],
    },
    initialState: {
      columnVisibility: {
        ...columns.reduce(
          (prev, curr: any) => ({
            ...prev,
            [curr.accessorKey]:
              !curr.meta || (curr.meta && !curr.meta["hideColumn"]),
          }),
          {}
        ),
        ...(tableMetaData?.visibilityObject
          ? tableMetaData?.visibilityObject
          : {}),
      },
      columnOrder: tableMetaData?.columnOrder || [],
    },
    globalFilterFn: "auto",
    columnResizeMode: "onEnd",
    columnResizeDirection: "ltr",
    getCoreRowModel: getCoreRowModel(),
    onPaginationChange: setPagination,
    onGlobalFilterChange: setGlobalFilter,
    getPaginationRowModel: !disablePagination
      ? getPaginationRowModel()
      : undefined,
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getSubRows: (row) => row.children, // return the children array as sub-rows
    getExpandedRowModel: getExpandedRowModel(),

    // manualSorting: !!url,
    manualPagination: !!url,
    enableGlobalFilter: !url,
    autoResetPageIndex: !url,
    enableMultiRowSelection: false,
    meta: {
      updateData: (rowIndex, columnId, value, keyID) => {
        console.log(keyID);
        // console.log(table.getRowModel().rows[rowIndex].original);

        // Skip page index reset until after next rerender
        if (onRowChange) {
          skipAutoResetPageIndex();
          const rows = onRowChange(
            tableData.rows,
            rowIndex,
            columnId,
            value,
            keyID
          );

          setTableData((prev: any) => ({ ...prev, rows }));
          if (url) {
            queryClient.refetchQueries({
              queryKey: [url],
            });
          }
        }
      },
    },
  });
  let state = table.getState();

  useEffect(() => {
    setSelectedId?.(table.getSelectedRowModel().rows[0]?.original?.id);
    setRowSelection?.(table.getSelectedRowModel().rows[0]?.original);
  }, [table.getState().rowSelection]);

  //  useQuery({
  //   queryKey: [
  //     url,
  //     {
  //       limit: !disablePagination ? pagination.pageSize : undefined,
  //       page: !disablePagination ? pagination.pageIndex : undefined,
  //       sortField: state.sorting.length ? state.sorting[0].id : undefined,
  //       order: state.sorting.length
  //         ? state.sorting[0].desc
  //           ? "DESC"
  //           : "ASC"
  //         : undefined,
  //       filters: filters?.map((item: FilterColumnInterface) => ({
  //         column: item.column.id,
  //         field: item.column.optionAccessor,
  //         operator: item.operator.value,
  //         value:
  //           typeof item.value === "string"
  //             ? item.value
  //             : Array.isArray(item.value)
  //             ? item.value.map(
  //                 (value) =>
  //                   item.column.optionAccessor &&
  //                   value[item.column.optionAccessor]
  //               )
  //             : item.column.optionAccessor &&
  //               item.value[item.column.optionAccessor],
  //       })),
  //     },
  //   ],
  // });
  const dataQuery = useQuery<ResponseInterface<any>>({
    queryKey: [
      url,
      {
        limit: !disablePagination ? pagination.pageSize : undefined,
        page: !disablePagination ? pagination.pageIndex : undefined,
        sortField: state.sorting.length ? state.sorting[0].id : undefined,
        order: state.sorting.length
          ? state.sorting[0].desc
            ? "DESC"
            : "ASC"
          : undefined,
        filters: filters?.map((item: FilterColumnInterface) => ({
          column: item.column.id,
          field: item.column.optionAccessor,
          operator: item.operator.value,
          value:
            typeof item.value === "string"
              ? item.value
              : Array.isArray(item.value)
              ? item.value.map(
                  (value) =>
                    item.column.optionAccessor &&
                    value[item.column.optionAccessor]
                )
              : item.column.optionAccessor &&
                item.value[item.column.optionAccessor],
        })),
      },
    ],
    enabled: !!url,
    placeholderData: keepPreviousData, // don't have 0 rows flash while changing pages/loading next page
    initialData: { count: 0, rows: [] },
    select: (res: any) => res?.data,
  });

  // console.log(dataQuery, "<-------------- dataQuerydataQuery");

  useEffect(() => {
    if (url && dataQuery.data) {
      setTableData({
        count: dataQuery?.data?.count || 0,
        rows: dataQuery?.data?.rows || [],
      });

      // setTableData(dataQuery.data);
    } else {
      setTableData({ count: data?.length || 0, rows: data || [] });
    }
  }, [dataQuery.data, url, data]);
  const onSave = (
    visibilityObject: Record<string, boolean>,
    columnOrder: string[]
  ) => {
    table.setColumnVisibility(visibilityObject);
    table.setColumnOrder(columnOrder);
    postMetaData({
      visibilityObject,
      columnOrder,
      filters,
      pagination,
      globalFilter,
      sorting: state.sorting,
    });
  };

  const postData = (perfrences: any) => {
    return axios
      .post("admin/preference", { preference: perfrences })
      .catch((err) => {
        if (Axios.isCancel(err)) {
          console.log("request cannceld");
        } else {
          throw err;
        }
      });
  };

  const { mutate } = useMutation({
    mutationKey: [tableMetaDataKey],
    mutationFn: postData,
  });

  const postMetaData = ({
    pagination,
    filters,
    sorting,
    visibilityObject,
    columnOrder,
  }: {
    pagination: any;
    globalFilter: string;
    filters: any;
    sorting: any;
    visibilityObject?: Record<string, boolean>;
    columnOrder?: string[];
  }) => {
    let perfrences: any = JSON.parse(localStorage.getItem("user_pref")!);

    if (tableMetaDataKey) {
      perfrences = {
        ...perfrences,
        tableMetaData: {
          ...perfrences?.tableMetaData,

          [tableMetaDataKey]: {
            ...pagination,
            visibilityObject: visibilityObject
              ? visibilityObject
              : perfrences?.tableMetaData?.[tableMetaDataKey]
                  ?.visibilityObject || {},
            columnOrder: columnOrder
              ? columnOrder
              : perfrences?.tableMetaData?.[tableMetaDataKey]?.columnOrder ||
                [],
            // search: globalFilter,
            sorting: sorting,
            filters: filters,
          },
        },
      };
      mutate(perfrences, {
        onSuccess: () => {
          localStorage.setItem(`user_pref`, JSON.stringify(perfrences));
        },
      });
    }
  };

  /**
   * * ************* DOWNLOAD EXCEL ************
   */

  const [isDownloading, setIsDownloading] = useState(false);
  const [excelLoading, setExcelloading] = useState(false);

  function extractFilenameWithoutExtension(filePath: string): string {
    const parts = filePath?.split("/");
    return parts[parts?.length - 1];
  }

  function removePublicFromPath(path: string): string {
    return path?.replace("./public", "");
  }

  function downloadFile(url: string, fileName: string) {
    const a = document.createElement("a");
    a.href = process.env.REACT_APP_API_BASE_URL + url;

    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setExcelloading(false);
    setIsDownloading(false);
  }
  const handleDownload = async () => {
    try {
      setExcelloading(true);
      setIsDownloading(true);
      let resp: any = await axios.get(
        `${url}${url?.includes("?") ? "&" : "?"}download=true`,
        {
          params: {
            filters: filters.map((item: FilterColumnInterface) => ({
              column: item.column.id,
              field: item.column.optionAccessor,
              operator: item.operator.value,
              value:
                typeof item.value === "string"
                  ? item.value
                  : Array.isArray(item.value)
                  ? item.value.map(
                      (value) =>
                        item.column.optionAccessor &&
                        value[item.column.optionAccessor]
                    )
                  : item.column.optionAccessor &&
                    item.value[item.column.optionAccessor],
            })),
          },
        }
      );

      downloadFile(
        removePublicFromPath(resp),
        extractFilenameWithoutExtension(resp)
      );
      setExcelloading(false);
      setIsDownloading(false);
    } catch (error: any) {
      setExcelloading(false);
      setIsDownloading(false);
      if (error?.response?.data?.msg) {
        toast.error(error.response.data.msg);
      } else {
        toast.error("Something went wrong");
      }
    }
  };

  // useEffect(() => {
  //   postMetaData({
  //     pagination,
  //     filters,
  //     sorting: state.sorting,
  //     globalFilter: debouncedQuery,
  //   });
  // }, [debouncedQuery]);

  return (
    <div className="my-7 w-full">
      <div className="my-5 flex justify-between lg:items-center items-end lg:flex-row  flex-col gap-5 flex-wrap">
        <div className="flex justify-start items-center gap-3 md:w-auto w-full">
          {!disableSearch && (
            <SearchInput
              containerClass="md:w-[350px] w-full"
              inputProps={{
                onChange: (e) => {
                  setGlobalFilter(e.target.value);
                  table.setPageIndex(0);
                },
                value: globalFilter,
              }}
            />
          )}
          {!disableFilters && (
            <>
              <div className="md:flex gap-3 justify-start hidden">
                <div className="w-[1px] h-10 bg-gray-200 hidden md:block"></div>
                <ApplyFilter
                  columns={table.getAllColumns()}
                  setFilters={setFilters}
                  filters={filters}
                  changePage={(filters: any) => {
                    table.setPageIndex(0);
                    postMetaData({
                      pagination,
                      globalFilter,
                      sorting: state.sorting,
                      filters: filters,
                    });
                  }}
                />
                {!!filters.length && (
                  <CustomButton
                    className="border-[#BEC8D0] rounded px-4 text-neutral-600"
                    onClick={() => {
                      setFilters([]);
                      postMetaData({
                        pagination,
                        globalFilter,
                        sorting: state.sorting,
                        filters: [],
                      });
                      table.setPageIndex(0);
                    }}
                  >
                    <span className="hidden md:inline">Reset Filters</span>
                  </CustomButton>
                )}
              </div>
            </>
          )}
        </div>
        <div className="flex justify-end items-center gap-3 ">
          {!disableFilters && (
            <>
              <div className="flex gap-3 justify-start md:hidden">
                <ApplyFilter
                  columns={table.getAllColumns()}
                  setFilters={setFilters}
                  filters={filters}
                  changePage={(filters: any) => {
                    table.setPageIndex(0);
                    postMetaData({
                      pagination,
                      globalFilter,
                      sorting: state.sorting,
                      filters: filters,
                    });
                  }}
                />
                <div className="w-[1px] h-10 bg-gray-200"></div>
              </div>
            </>
          )}

          {/* {extraButtons && <div className="w-[1px] h-10 bg-gray-200"></div>} */}
          {extraButtons}
          {excelDownload && <div className="w-[1px] h-10 bg-gray-200"></div>}
          {excelDownload && !excelLoading ? (
            <CustomButton
              variant="outline"
              color="primary"
              onClick={handleDownload}
              disabled={isDownloading ? true : false}
            >
              {" "}
              <span className="hidden md:inline">Download</span>
            </CustomButton>
          ) : (
            ""
          )}
          {/* {excelLoading && <CircularProgress />} */}
        </div>
      </div>

      <div className="lg:w-full w-[calc(100vw_-_60px)]  overflow-auto min-h-[300px]">
        <table
          {...{
            style: {
              minWidth: "100%",
              width: table.getCenterTotalSize(),
            },
          }}
        >
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    colSpan={header.colSpan}
                    className={cn(
                      "bg-[#F5F8FF] h-[52px] text-start px-3 font-normal text-sm text-primary-text border-b border-[#2970FF] relative group"
                    )}
                    style={{ width: header.getSize(), minWidth: "100%" }}
                    key={header.id}
                  >
                    <div
                      onClick={header.column.getToggleSortingHandler()}
                      className={cn(
                        "flex justify-between items-center h-full",
                        {
                          "cursor-pointer": header.column.getCanSort(),
                        }
                      )}
                    >
                      <div className="flex justify-start items-center gap-2">
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                        {header.column.getCanSort() &&
                          ({
                            asc: (
                              <TiArrowSortedDown
                                size={15}
                                className="text-inherit text-base"
                              />
                            ),
                            desc: (
                              <TiArrowSortedUp
                                size={15}
                                className="text-inherit text-base"
                              />
                            ),
                          }[header.column.getIsSorted() as string] ?? (
                            <TiArrowUnsorted
                              size={15}
                              className="text-inherit text-base"
                            />
                          ))}
                      </div>
                    </div>
                    <div
                      className={cn(
                        "w-0 group-hover:w-[4px] h-full bg-orange-200 absolute right-0 top-0 hover:bg-primary z-[1000] cursor-col-resize",
                        {
                          "bg-primary": header.column.getIsResizing(),
                        }
                      )}
                      {...{
                        onDoubleClick: () => header.column.resetSize(),
                        onMouseDown: header.getResizeHandler(),
                        onTouchStart: header.getResizeHandler(),

                        style: {
                          transform: header.column.getIsResizing()
                            ? `translateX(${
                                1 *
                                (table.getState().columnSizingInfo
                                  .deltaOffset ?? 0)
                              }px)`
                            : "",
                        },
                      }}
                    />
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {/* {dataQuery.isFetching && (
              <tr>
                <td colSpan={table.getVisibleFlatColumns().length}>
                </td>
              </tr>
            )} */}

            {/* {!tableData?.rows?.length && (
              <tr>
                <td colSpan={table.getVisibleFlatColumns().length}>
                  <NoData />
                </td>
              </tr>
            )} */}

            {table.getRowModel().rows.map((row) => (
              <tr className="hover:bg-gray-100" key={row.id}>
                {row.getVisibleCells().map((cell) => (
                  <td
                    key={cell.id}
                    className={cn(
                      "h-10 px-3 border-b border-b-[#C9C5CA] text-neutral-600 text-[13px]"
                    )}
                  >
                    {flexRender(
                      cell.column.columnDef.cell,
                      cell.getContext()
                    ) || "-"}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!disablePagination && (
        <div className="flex justify-between items-center my-[10px]">
          <div className="justify-start  items-center gap-4 flex">
            <div className="text-gray-400 w-[180px] text-xs md:block hidden">
              Showing {pagination.pageIndex + 1} to{" "}
              {(pagination.pageIndex + 1) * pagination.pageSize} of{" "}
              {tableData.count?.toLocaleString()} Entries
            </div>
            <div className="w-[1px] h-4 bg-gray-200  md:block hidden"></div>
            <div className="text-primary-text text-xs md:block hidden">
              Show
            </div>
            <CustomSelect
              name=""
              className="w-[68px] h-[32px]"
              options={[2, 10, 25, 50]}
              value={pagination.pageSize}
              onChange={(selectedItem) => {
                table.setPageSize(selectedItem);
                table.setPageIndex(0);
                postMetaData({
                  pagination: {
                    ...pagination,
                    pageSize: selectedItem,
                  },
                  globalFilter,
                  sorting: state.sorting,
                  filters: filters,
                });
              }}
              getOptionLabel={(option) => option.toString()}
              getOptionValue={(option) => option.toString()} // Added getOptionValue
            />
            <div className="text-primary-text text-xs md:block hidden">
              Entries
            </div>
          </div>
          <div className=" ">
            <Pagination aria-label="pagination" className="my-4">
              <PaginationPrevious
                onClick={() => handlePageChange(currentPage - 1)}
              ></PaginationPrevious>
              <PaginationContent>
                {currentPage > 2 && (
                  <PaginationItem>
                    <PaginationEllipsis />
                  </PaginationItem>
                )}

                {pageLinks.map((page: any) => (
                  <PaginationItem key={page}>
                    <PaginationLink
                      isActive={currentPage === page}
                      onClick={() => handlePageChange(page)}
                    >
                      {page}
                    </PaginationLink>
                  </PaginationItem>
                ))}

                {currentPage < totalPages - 1 && (
                  <PaginationItem>
                    <PaginationEllipsis />
                  </PaginationItem>
                )}
              </PaginationContent>
              <PaginationNext
                onClick={() => handlePageChange(currentPage + 1)}
              ></PaginationNext>
            </Pagination>
          </div>
        </div>
      )}
    </div>
  );
};
