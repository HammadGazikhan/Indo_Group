import * as React from "react";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "../label";
import { useField, useFormikContext } from "formik";

export function Autocomplete({
  name,
  label,
  options,
  placeholder,
  defaultValue,
  onChange,
  value: propValue,
  className,
}: any) {
  const formik = useFormikContext();
  let field, meta, helpers;

  const isFormik = !!(formik && name);
  if (isFormik) {
    // eslint-disable-next-line
    [field, meta, helpers] = useField(name);
  }

  const [localValue, setLocalValue] = React.useState(defaultValue || "");
  const [open, setOpen] = React.useState(false);

  const value = isFormik ? field?.value : propValue ?? localValue;
  const setValue =
    isFormik && helpers?.setValue
      ? helpers.setValue
      : (val: string) => {
          setLocalValue(val);
          if (onChange) onChange(val);
        };

  return (
    <div className="flex flex-col rounded-sm">
      {label && <Label className="capitalize">{label}</Label>}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className={`w-[300px] h-[48px] justify-between text-[#2E3545] rounded-sm ${className}`}
          >
            {value
              ? options.find((option: any) => option.value === value)?.label ||
                options.find((option: any) => option?.header === value)?.header
              : placeholder || "Select..."}
            <ChevronDown className="opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0">
          <Command>
            <CommandInput placeholder="Search..." />
            <CommandList>
              <CommandEmpty>No Data found.</CommandEmpty>
              <CommandGroup>
                {options?.map((option: any) => (
                  <CommandItem
                    key={option.value || option?.header}
                    value={option.value || option?.header}
                    onSelect={() => {
                      setValue(option.value || option?.header);
                      setOpen(false);
                    }}
                  >
                    {option.label || option?.header}
                    <Check
                      className={cn(
                        "ml-auto",
                        value === option.value || value === option?.header
                          ? "opacity-100"
                          : "opacity-0"
                      )}
                    />
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
