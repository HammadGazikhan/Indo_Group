import { useField } from "formik";
import { Input } from "@/components/ui/input";
import { Label } from "../label";
import { Button } from "../ui/button";
import CustomButton from "../button";
import { CornerRightUp } from "lucide-react";

export function InputFile({ name, label }: { name: string; label?: string }) {
  const [, , helpers] = useField(name);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    helpers.setValue(file);
  };

  return (
    <div className="grid w-full max-w-sm items-center gap-1.5">
      <Label>{label}</Label>
      <div className="flex ">
        <Input
          id={name}
          type="file"
          onChange={handleChange}
          placeholder="upload"
          className="rounded-r-none "
        />
        <CustomButton className="!h-[48px] rounded-l-none">
          <CornerRightUp />
          Upload
        </CustomButton>
      </div>
    </div>
  );
}
