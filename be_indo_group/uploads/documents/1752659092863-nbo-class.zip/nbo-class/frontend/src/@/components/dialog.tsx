import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import React, { cloneElement, ReactNode, useEffect, useState } from "react";

interface Props {
  button?: any;
  title?: any;
  children?: ReactNode | ((props: { onClose: () => void }) => ReactNode);
  buttonOnClick?: () => void;
  onClose?: (e?: any, reason?: string) => void;
  fullScreen?: boolean;
  footer?: ({ onClose }: { onClose: () => void }) => ReactNode;
  className?: any;
}

export function CustomDialog({
  button,
  title,
  children,
  buttonOnClick,
  onClose: onCloseCall,
  footer,
  fullScreen,
  className,
}: Props) {
  const [open, setOpen] = useState(false);

  const onOpen = () => {
    button?.props?.onClick?.();
    setOpen(true);
  };

  const onClose = (e?: any, reason?: string) => {
    if (reason !== "backdropClick") {
      setOpen(false);
      onCloseCall?.(e, reason);
    }
  };

  useEffect(() => {
    if (!button) {
      setOpen(true);
    }
  }, [button]);

  return (
    <>
      {button &&
        cloneElement(button, {
          onClick: () => {
            buttonOnClick?.();
            onOpen();
          },
        })}
      <Dialog open={open} onOpenChange={setOpen} modal={true}>
        <DialogContent
          className={`min-w-32 bg-white !overflow-y-auto max-h-screen ${
            fullScreen ? "w-full h-full" : ""
          } ${className}`}
        >
          <DialogHeader className="border-b py-8">
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>
          {typeof children === "function" ? children({ onClose }) : children}
          {footer && (
            <DialogFooter className="py-4 px-6 border-t">
              {footer({ onClose })}
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
