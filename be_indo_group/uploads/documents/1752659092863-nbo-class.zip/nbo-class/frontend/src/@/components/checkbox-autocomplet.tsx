import { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Badge } from "./ui/badge";
import { Label } from "./label";

const levels = [
  { id: 1, label: "Level 1" },
  { id: 2, label: "Level 2" },
  { id: 3, label: "Level 3" },
  { id: 4, label: "Level 4" },
];

export default function CheckBoxAutocomplet({
  label,
  className,
}: {
  label: string;
  className?: any;
}) {
  const [selectedLevels, setSelectedLevels] = useState<number[]>([]);
  const [open, setOpen] = useState(false);

  const toggleLevel = (id: number) => {
    setSelectedLevels((prev) =>
      prev.includes(id) ? prev.filter((level) => level !== id) : [...prev, id]
    );
  };

  return (
    <div className="flex flex-col !rounded-[5px] py-10">
      {label && <Label>{label}</Label>}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={`w-full justify-between h-[48px] flex-wrap !rounded-[5px] p-2 ${className}`}
          >
            {selectedLevels.length > 0 ? (
              <div className="flex flex-wrap gap-1">
                {selectedLevels.map((id) => {
                  const level = levels.find((lvl) => lvl.id === id);
                  return (
                    level && (
                      <Badge
                        key={id}
                        variant="default"
                        className="px-2  mx-1 h-[32px] rounded-sm py-1"
                      >
                        {level.label}
                      </Badge>
                    )
                  );
                })}
              </div>
            ) : (
              <span className="text-[#5F6D7E]">Select Levels</span>
            )}
            {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[514px] p-2">
          <div className="flex flex-col gap-2">
            {levels.map((level) => (
              <div key={level.id} className="flex items-center gap-2">
                <Checkbox
                  id={`level-${level.id}`}
                  checked={selectedLevels.includes(level.id)}
                  onCheckedChange={() => toggleLevel(level.id)}
                />
                <label
                  htmlFor={`level-${level.id}`}
                  className="text-sm font-medium cursor-pointer"
                >
                  {level.label}
                </label>
              </div>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
