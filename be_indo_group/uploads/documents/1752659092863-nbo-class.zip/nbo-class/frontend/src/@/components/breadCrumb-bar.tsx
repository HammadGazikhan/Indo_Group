import { ChevronRight } from "lucide-react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "./ui/breadcrumb";
import { useIsMobile } from "@/hooks/use-mobile";
import { SidebarTrigger } from "./ui/sidebar";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { IoMdArrowDropdown } from "react-icons/io";

export function BreadcrumbBar() {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const location = useLocation();

  const [searchParams] = useSearchParams();

  let pathnameArr = location?.pathname?.slice(1)?.split("/");
  const firstParam = Array.from(searchParams.entries())[0];
  if (firstParam) {
    const [key, value] = firstParam;
    pathnameArr.push(`${value}`);
  }
  return (
    <Breadcrumb
      className={`!h-[72px] flex justify-between ${
        isMobile ? "w-full" : "w-[calc(100vw_-_319px)] left-[319px]"
      }   fixed !bg-white flex items-center border-b-[1.33px] border-[#DAE0E6] px-4 z-10`}
    >
      <div className="flex items-center">
        <div className="w-[39px] h-[39px] mr-4" onClick={() => navigate(-1)}>
          {/* <div className="w-[39px] h-[39px] mr-4"> */}
          <img src="./icons/Breadcrumbar-back-button.svg" />
        </div>
        <div>
          <h5 className="font-medium capitalize flex gap-1 items-center">
            {/* {pageTitle} */}
            {pathnameArr[0]}
            <IoMdArrowDropdown />
          </h5>
          {/* <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <ChevronRight />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink href="/components">Components</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <ChevronRight />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>Breadcrumb</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList> */}
          <BreadcrumbList>
            {pathnameArr?.length > 0 &&
              pathnameArr?.map((item: string, index: number) =>
                index === pathnameArr?.length - 1 ? (
                  <>
                    <BreadcrumbItem>
                      <BreadcrumbLink href="/" className="text-[#528BFF]">
                        {item?.replace(/([.?*+^$[\]\\(){}-])/g, " ")}
                      </BreadcrumbLink>
                    </BreadcrumbItem>
                  </>
                ) : (
                  <BreadcrumbItem>
                    <BreadcrumbLink href="/">
                      {item?.replace(/([.?*+^$[\]\\(){}-])/g, " ")}
                    </BreadcrumbLink>
                    {index !== pathnameArr?.length - 1 && (
                      <BreadcrumbSeparator>
                        <ChevronRight />
                      </BreadcrumbSeparator>
                    )}
                  </BreadcrumbItem>
                )
              )}
          </BreadcrumbList>
        </div>
      </div>
      {isMobile && <SidebarTrigger />}
    </Breadcrumb>
  );
}
