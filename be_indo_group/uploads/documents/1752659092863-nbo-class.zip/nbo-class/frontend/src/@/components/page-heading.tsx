import { cn } from "@/lib/utils";
import React, { ReactNode } from "react";

export const PageHeading = ({
  className,
  children,
  variant = "primary",
}: {
  className?: string;
  children: ReactNode;
  variant?: "primary" | "secondary";
}) => {
  return (
    <div
      className={cn(
        " font-medium text-lg relative h-[42px] mb-10  flex justify-start items-center",
        className,
        {
          "h-8 text-primary": variant === "primary",
          "h-8 text-black": variant === "secondary",
        }
      )}
    >
      <div
        className={cn("block w-1 h-[24px] rounded-r-sm mr-2", {
          "bg-primary": variant === "primary",
          "bg-[#EEA23E] ": variant === "secondary",
        })}
      ></div>
      {children}
    </div>
  );
};
