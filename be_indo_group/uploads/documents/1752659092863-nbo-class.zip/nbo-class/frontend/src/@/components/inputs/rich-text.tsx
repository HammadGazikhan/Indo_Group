import { useField } from "formik";
import React from "react";
import { Label } from "../label";
import ReactQuill from "react-quill-new";
interface RichTextEditorProps {
  name: string;
  required?: boolean;
  label?: string;
  disabled?: boolean;
  onChange?: (value: any) => void;
  containerClassName?: string;
}

const modules = {
  toolbar: [
    [{ size: [] }],
    ["bold", "italic", "underline", "strike"],
    [{ color: [] }, { background: [] }],
    [{ align: [] }],

    [{ list: "ordered" }, { list: "bullet" }],

    ["link", "image"],
  ],
};

const formats: string[] = [
  "header",
  "font",
  "size",
  "bold",
  "italic",
  "underline",
  "strike",
  "blockquote",
  "list",
  "bullet",
  "indent",
  "link",
  "image",
];

const RichTextEditor: React.FC<RichTextEditorProps> = ({
  name,
  required,
  label,
  disabled,
  onChange,
  containerClassName,
}) => {
  let fieldOptions: any = {};

  const [inputProps, inputMetaProps, helpers] = useField(name);

  fieldOptions = {
    ...inputProps,
    error: !!(inputMetaProps.touched && inputMetaProps.error),
    helperText:
      inputMetaProps.touched && inputMetaProps.error
        ? inputMetaProps.error
        : "",
  };
  return (
    <div className={containerClassName || ""}>
      {label && (
        <Label required={required}>
          <span style={{ textTransform: "capitalize" }}>{label}</span>
        </Label>
      )}

      <ReactQuill
        style={{}}
        readOnly={disabled}
        value={inputProps.value}
        onChange={(value: any) => {
          helpers.setValue(value);
          onChange && onChange(value);
        }}
        onBlur={() => helpers.setTouched(true)}
        modules={modules}
        formats={formats}
        className="mt-2 custom-toolbar "
      />
    </div>
  );
};

export default RichTextEditor;
