import React from "react";
import { Button } from "./ui/button";

interface CustomButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:
    | "default"
    | "destructive"
    | "outline"
    | "secondary"
    | "ghost"
    | "link";
}

const CustomButton: React.FC<CustomButtonProps> = ({
  type = "button",
  variant = "default",
  className,
  ...props
}) => {
  return (
    <Button
      type={type as "button" | "submit" | "reset"}
      variant={variant}
      {...props}
      className={`h-[36px] rounded-[4px] text-[13px] capitalize ${className}`}
    ></Button>
  );
};

export default CustomButton;
