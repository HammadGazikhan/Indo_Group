import React from "react";
import { TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Tabs } from "@radix-ui/react-tabs";

const CustomTab = ({
  tabs,
  className,
  value,
  setValue,
}: {
  tabs: { label: string; value: number | string }[];
  className?: string;
  setValue: React.Dispatch<React.SetStateAction<number | string>>;
  value: any;
}) => {
  return (
    <Tabs value={value} onValueChange={setValue} className={` ${className}`}>
      <TabsList className="bg-[#EFF4FF] !rounded-[8.91px] !h-[40px] mx-auto">
        {tabs.map((item) => (
          <TabsTrigger key={item.value} value={String(item.value)}>
            {item.label}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
};

export default CustomTab;
