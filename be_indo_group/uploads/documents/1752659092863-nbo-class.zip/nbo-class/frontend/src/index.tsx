import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, RouterProvider, Routes } from "react-router";
import { router } from "./app-router";
import "./index.css";
import Layout from "pages/layout";
import { LoginPage } from "pages/login/page";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import FacilitiesPage from "pages/configs/facilities/page";
import ParticipantsPage from "pages/configs/participants/page";
import ParticipantsForm from "pages/configs/participants/participantsForm/page";
import LeadershipLevelsPage from "pages/configs/leadership-levels/page";
import CompetenciesPage from "pages/configs/competencies/page";
import ExpectedBehaviorsPage from "pages/configs/competencies/expected-behaviors/page";
import AssessorsPage from "pages/configs/assessors/page";
import ClassConfigurationPage from "pages/configs/class-configuration/page";
import AssessmentConfigPage from "pages/configs/assessment/page";
import AssessmentsPage from "pages/assessments/page";
import AssessNowPage from "pages/assessments/assess -now/page";
import ClientsPage from "pages/configs/clients/page";
import SchedulesPage from "pages/schedules/page";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
const queryClient = new QueryClient();
root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="facilities-config" element={<FacilitiesPage />} />
            <Route path="participants-config">
              <Route index element={<ParticipantsPage />} />
              <Route path="participantsForm" element={<ParticipantsForm />} />
            </Route>
            <Route
              path="leadership-levels-config"
              element={<LeadershipLevelsPage />}
            />
            <Route path="competencies-config">
              <Route index element={<CompetenciesPage />} />
              <Route
                path="expected-behaviors"
                element={<ExpectedBehaviorsPage />}
              />
            </Route>
            <Route path="assessors-config" element={<AssessorsPage />} />
            <Route
              path="class-configuration-config"
              element={<ClassConfigurationPage />}
            />
            <Route path="clients-config" element={<ClientsPage />} />
            <Route path="schedules" element={<SchedulesPage />} />
            <Route
              path="assessment-config"
              element={<AssessmentConfigPage />}
            />
            <Route path="assessments">
              <Route index element={<AssessmentsPage />} />
              <Route path="assess-now" element={<AssessNowPage />} />
            </Route>
          </Routes>
        </Layout>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
  // <React.StrictMode>
  //   <Layout>
  //     <RouterProvider router={router} />
  //   </Layout>
  // </React.StrictMode>
);
