import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { GoUpload } from "react-icons/go";
import React, { useEffect, useState } from "react";
import FacilitiesForm from "./components/FacilitiesForm";
import { useQuery } from "@/hooks/useQuerry";
import { Item } from "@radix-ui/react-accordion";
import { BiEditAlt } from "react-icons/bi";
import { Separator } from "@/components/ui/separator";
import { DeleteItem } from "@/components/delete-item";

const FacilitiesPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Facilities name",
      accessorKey: "facilityName",
    },
    {
      header: "Address",
      accessorKey: "address",
    },
    {
      header: "Rooms",
      accessorKey: "room",
      cell({ row }: { row: any }) {
        return (
          console.log(row),
          row.original?.room?.map((item: any) => item?.room)?.join(", ") || ""
        );
      },
    },
    {
      header: "Action",
      accessorKey: "Action",
      cell({ row }) {
        return (
          <div className="flex justify-start items-center gap-5">
            <span
              className="flex gap-1 items-center cursor-pointer text-[#006F6D]"
              onClick={() => {
                // eslint-disable-next-line
                setOpen(true), setSelectedRow(row?.original);
              }}
            >
              <BiEditAlt className="text-[#006F6D] size-[14px]" />
              Edit
            </span>
            <Separator
              orientation="vertical"
              className="!h-[15px] text-red-500"
            />

            <DeleteItem
              endPoint={`/facility/${row?.original?.id}`}
              itemName={`${row?.original?.facilityName}`}
              title="Delete Client"
              refetchUrl={["/client"]}
            />
          </div>
        );
      },
    },
  ];
  const [selectedRow, setSelectedRow] = useState<any>(null);
  const [open, setOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<any>();

  const { data: ClientData } = useQuery<any>({
    queryKey: [`/client/getall-clients`],
    select: (data: any) => data?.data?.rows,
    enabled: true,
  });
  // const { data: DatagridData } = useQuery<any>({
  //   queryKey: [`/facility/${selectedClient?.projects[0]?.id}`],
  //   select: (data: any) => data?.data?.rows,
  //   enabled: !!selectedClient,
  // });

  // useEffect(() => {
  //   if (DatagridData?.length && columns?.length < 1) {
  //     let tempCols: ColumnDef<any>[] = [];
  //     DatagridData[0]?.room?.map((item: any, index: number) => {
  //       tempCols.push({
  //         header: `Room ${index + 1}`,
  //         accessorKey: "room",
  //         cell: ({ row }) => {
  //           return row?.original?.room[index]?.room;
  //         },
  //       });
  //     });
  //     console.log(tempCols, ",==tempcols");
  //     setColumns([
  //       ...columns,
  //       ...tempCols,
  //       {
  //         header: "Action",
  //         accessorKey: "Action",
  //       },
  //     ]);
  //     // columns = ;
  //   }
  // }, [DatagridData]);
  return (
    <div>
      <PageHeading>Facilities</PageHeading>
      <div className="flex gap-10 mb-10">
        <CustomSelect
          name="client"
          className="w-[494.33px] h-[48px]"
          label="Select Client"
          options={ClientData}
          getOptionLabel={(item: any) => item?.clientName}
          getOptionValue={(item: any) => item}
          onChange={(item) => setSelectedClient(item)}
        />
      </div>
      {selectedClient?.projects[0]?.id && (
        <Datagrid
          columns={columns}
          url={
            selectedClient?.projects[0]?.id
              ? `/facility/${selectedClient?.projects[0]?.id}`
              : ""
          }
          // data={DatagridData}
          extraButtons={
            <>
              <CustomButton variant="outline">
                <GoUpload />
                Excel Upload Facility
              </CustomButton>
              <CustomButton variant="default" onClick={() => setOpen(true)}>
                <Plus />
                Add New Facility
              </CustomButton>
            </>
          }
        ></Datagrid>
      )}

      {open && (
        <FacilitiesForm
          setOpen={setOpen}
          projectId={selectedClient?.projects[0]?.id}
          facility={selectedRow}
        />
      )}
    </div>
  );
};

export default FacilitiesPage;
