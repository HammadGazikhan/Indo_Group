import React, { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { FiAlertCircle } from "react-icons/fi";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ButtonFooter, ConfirmDialog, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
const AssessNowPage = () => {
  const [open, setOpen] = useState(false);
  const data = [
    {
      competency: "Business Acumen",
      behaviors: [
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
      ],
    },
    {
      competency: "Business Acumen",
      behaviors: [
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
      ],
    },
    {
      competency: "Business Acumen",
      behaviors: [
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
        "The majority of our global interviews take place in line with local academic calendars, typically August–February",
      ],
    },
  ];
  return (
    <>
      <PageHeading>Participant: Anas</PageHeading>
      <div className="mb-10">
        <CustomSelect
          name="select"
          className="w-[449px]"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        />
      </div>
      <div className="overflow-x-auto">
        <Table className="w-full border">
          <TableHeader>
            <TableRow className="bg-[#EFF4FF] h-[60px] w-[153px]">
              <TableHead className="w-1/6">Competency</TableHead>
              <TableHead className="w-1/3">Expected Behaviors</TableHead>
              <TableHead className="w-1/12">Score (Out of 5)</TableHead>
              <TableHead className="w-1/4">Remarks</TableHead>
              <TableHead className="w-1/4">Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item, index) => (
              <>
                {item.behaviors.map((behavior, subIndex) => (
                  <TableRow key={`${index}-${subIndex}`}>
                    {subIndex === 0 && (
                      <TableCell
                        rowSpan={item.behaviors.length}
                        className="align-top border-r "
                      >
                        {item.competency}
                      </TableCell>
                    )}
                    <TableCell className="border-r ">{behavior}</TableCell>
                    {subIndex === 0 && (
                      <TableCell
                        className="align-top border-r "
                        rowSpan={item.behaviors.length}
                      >
                        <Select>
                          <SelectTrigger className="w-16">
                            <SelectValue placeholder="" />
                          </SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4, 5].map((score) => (
                              <SelectItem
                                key={score}
                                value={String(score)}
                                className="w-full"
                              >
                                {score}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                    )}
                    {subIndex === 0 && (
                      <TableCell
                        className="align-top border-r h-full"
                        rowSpan={item.behaviors.length}
                      >
                        <Textarea
                          placeholder="Enter remarks..."
                          className="w-full !h-full"
                        />
                      </TableCell>
                    )}
                    {subIndex === 0 && (
                      <TableCell
                        className="align-top "
                        rowSpan={item.behaviors.length}
                      >
                        <Textarea
                          placeholder="Enter notes..."
                          className="w-full !h-full"
                        />
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </>
            ))}
          </TableBody>
        </Table>
        <ButtonFooter>
          <div className="flex gap-4 justify-end">
            <CustomButton variant="outline">Cancel</CustomButton>
            <CustomButton onClick={() => setOpen(true)}>Save</CustomButton>
          </div>
        </ButtonFooter>
        {open && (
          <ConfirmDialog
            confirmMessage="Data cannot be changed after submitting."
            title={
              <span className="flex gap-3 items-center">
                <FiAlertCircle className="size-10 text-[#FFAE43]" /> Confirm
                Submission ?
              </span>
            }
            onClose={() => setOpen(false)}
          />
        )}
      </div>
    </>
  );
};

export default AssessNowPage;
