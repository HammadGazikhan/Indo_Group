import { PageHeading } from "@/components";
import ScheduleCalendar from "@/components/schedules-calender";
import React from "react";

const SchedulesPage = () => {
  const events = [
    {
      title: "Role Play @ AB123",
      start: {
        dateTime: "2024-02-18T21:00:00.000Z",
        timezone: "Mumbai/India",
      },
      end: {
        dateTime: "2024-02-19T06:30:00.000Z",
        timeZone: "Mumbai/India",
      },
    },
  ];
  return (
    <div>
      <PageHeading>Schedules</PageHeading>
      <ScheduleCalendar events={events} />
    </div>
  );
};

export default SchedulesPage;
