import { CustomDialog } from "@/components";
import CustomButton from "@/components/button";
import CustomInput from "@/components/inputs/custom-input";
import { DialogFooter } from "@/components/ui/dialog";
import { axios } from "@/config/axios";
import { queryClient } from "@/config/query-client";
import { useMutation } from "@tanstack/react-query";
import { Form, Formik, FieldArray } from "formik";
import React, { useState } from "react";
import { IoMdAdd } from "react-icons/io";
import { RxCross2 } from "react-icons/rx";
import { toast } from "sonner";

interface FacilitiesFormProps {
  setOpen: (open: boolean) => void;
  projectId?: number | string;
  facility?: any;
}

const FacilitiesForm: React.FC<FacilitiesFormProps> = ({
  setOpen,
  projectId,
  facility,
}) => {
  const { mutate, isPending } = useMutation({
    mutationFn: (data: any) =>
      facility
        ? axios.put(`/facility/${facility?.id}`, data)
        : axios.post(`/facility/${projectId}`, data),
    onSuccess: (data) => {
      toast.success(data.data.msg || "Successfully submitted!");
      queryClient.invalidateQueries({ queryKey: [`/client`] });
      setOpen(false);
    },
  });

  return (
    <CustomDialog
      title={projectId ? "Edit Facility" : "Add Facility"}
      className="max-w-[1116px]"
    >
      <Formik
        initialValues={{
          facilityName: facility?.facilityName || "",
          address: facility?.address || "",
          rooms: facility?.room?.map((item: any) => item?.room) || [""],
        }}
        onSubmit={(values) => {
          const formattedData = {
            facilityName: values.facilityName,
            address: values.address,
            rooms: values.rooms.map((room: any) => ({ room })),
          };
          mutate(formattedData);
        }}
      >
        {({ values, handleSubmit }) => (
          <Form>
            <div className="flex gap-5 flex-wrap">
              <CustomInput
                name="facilityName"
                label="Facility Name"
                className="w-[335px]"
              />
              <CustomInput
                name="address"
                label="Address"
                className="w-[335px]"
              />
            </div>

            <FieldArray
              name="rooms"
              render={({ push, remove }) => (
                <div className="flex flex-col gap-3 mt-3">
                  {values.rooms.map((_: any, index: any) => (
                    <div key={index} className="flex gap-3 items-center">
                      <CustomInput
                        name={`rooms.${index}`}
                        label={`Room ${index + 1}`}
                        className="w-[335px]"
                      />
                      <div className="flex gap-5">
                        <IoMdAdd
                          size={20}
                          className="text-green-500 cursor-pointer hover:text-green-700"
                          onClick={() => push("")}
                        />
                        {index > 0 && (
                          <RxCross2
                            size={20}
                            className="text-red-500 cursor-pointer hover:text-red-700"
                            onClick={() => remove(index)}
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            />

            <DialogFooter className="py-4 px-6 border-t">
              <div className="flex justify-end items-center gap-5">
                <CustomButton variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </CustomButton>
                <CustomButton
                  type="submit"
                  onClick={() => handleSubmit()}
                  disabled={isPending}
                >
                  {"Add"}
                </CustomButton>
              </div>
            </DialogFooter>
          </Form>
        )}
      </Formik>
    </CustomDialog>
  );
};

export default FacilitiesForm;
