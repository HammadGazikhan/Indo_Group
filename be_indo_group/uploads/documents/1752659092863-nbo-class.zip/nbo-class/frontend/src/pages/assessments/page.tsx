import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import FacilitiesForm from "pages/configs/facilities/components/FacilitiesForm";
import React from "react";
import { GoUpload } from "react-icons/go";

const AssessmentsPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Participants",
      accessorKey: "participants",
    },
    {
      header: "Assessment Name",
      accessorKey: "assessment_name",
    },
    {
      header: "Room Name",
      accessorKey: "room_name",
    },
    {
      header: "Date",
      accessorKey: "date",
    },
    {
      header: "Actions",
      accessorKey: "actions",
    },
  ];
  return (
    <div>
      <PageHeading>Assessments</PageHeading>
      <Datagrid
        columns={columns}
        url="https://dog.ceo/api/breeds/image/random"
      ></Datagrid>
    </div>
  );
};

export default AssessmentsPage;
