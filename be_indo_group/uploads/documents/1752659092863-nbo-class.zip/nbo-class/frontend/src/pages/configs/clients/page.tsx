import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import React, { useState } from "react";
import { IoMdAdd } from "react-icons/io";
import ClientConfigDialog from "./components/ClientDialog";
import { BiEditAlt } from "react-icons/bi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { Separator } from "@/components/ui/separator";
import { DeleteItem } from "@/components/delete-item";

const ClientsPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Client Name",
      accessorKey: "clientName",
    },
    {
      header: "Client Contact Person",
      accessorKey: "contactPersons",
      cell({ row }: { row: any }) {
        return row.original?.contactPersons?.[0]?.department || "";
      },
    },
    {
      header: "Project Name",
      accessorKey: "project_name",
      cell({ row }: { row: any }) {
        return row.original?.projects?.[0]?.projectName || "";
      },
    },
    {
      header: `Action`,
      accessorKey: "action",
      enableSorting: false,
      meta: {
        disableFilters: true,
      },
      cell({ row }) {
        return (
          <div className="flex justify-start items-center gap-5">
            <span
              className="flex gap-1 items-center cursor-pointer text-[#006F6D]"
              onClick={() => {
                // eslint-disable-next-line
                setOpen(true), setSelectedRow(row?.original?.id);
              }}
            >
              <BiEditAlt className="text-[#006F6D] size-[14px]" />
              Edit
            </span>
            <Separator
              orientation="vertical"
              className="!h-[15px] text-red-500"
            />

            <DeleteItem
              endPoint={`/client/${row?.original?.id}`}
              itemName={`${row?.original?.clientName}`}
              title="Delete Client"
              refetchUrl={["/client"]}
            />
          </div>
        );
      },
    },
  ];
  const [open, setOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState<any>(null);

  const handleDialogClose = () => {
    setOpen(false);
    setSelectedRow(null);
  };

  return (
    <div>
      <PageHeading>Client</PageHeading>
      <Datagrid
        url="/client"
        columns={columns}
        extraButtons={
          <CustomButton variant="outline" onClick={() => setOpen(true)}>
            <IoMdAdd />
            Add New
          </CustomButton>
        }
      />
      {open && (
        <ClientConfigDialog handleClose={handleDialogClose} id={selectedRow} />
      )}
    </div>
  );
};

export default ClientsPage;
