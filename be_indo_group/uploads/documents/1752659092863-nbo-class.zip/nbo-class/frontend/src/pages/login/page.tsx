import { CustomDialog, Label, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomAccordion from "@/components/custom-accordion";
import CustomTab from "@/components/custom-tab";
import {
  Autocomplete,
  CoustomTextarea,
  CustomCheckbox,
  DatePicker,
  DropZone,
  InputFile,
} from "@/components/inputs";
import CustomInput from "@/components/inputs/custom-input";
import CustomSelect from "@/components/inputs/custom-select";
import RichTextEditor from "@/components/inputs/rich-text";
import Stepper from "@/components/stepper";
import { DataTable } from "@/components/ui/datagrid/data-table";
import { Switch } from "@/components/ui/switch";
import { ColumnDef } from "@tanstack/react-table";
import { Formik } from "formik";
import React, { useState } from "react";
export const LoginPage = () => {
  const frameworks = [
    {
      value: "next.js",
      label: "Next.js",
    },
    {
      value: "sveltekit",
      label: "SvelteKit",
    },
    {
      value: "nuxt.js",
      label: "Nuxt.js",
    },
    {
      value: "remix",
      label: "Remix",
    },
    {
      value: "astro",
      label: "Astro",
    },
  ];

  const columns: ColumnDef<any>[] = [
    // {
    //   header: `${getLangValue("action", "Action")}`,
    //   accessorKey: "action",
    //   enableSorting: false,
    //   meta: {
    //     disableFilters: true,
    //   },
    //   maxSize: 40,
    //   cell({ row }) {
    //     return (
    //       <div className="flex justify-start items-center gap-5">
    //         <Link
    //           to={{
    //             pathname: `${updateURL}/${row.original.id}`,
    //             search: `inc_no=${row?.original?.incident_number}`,
    //           }}
    //         >
    //           <IconButton size="small">
    //             <HiOutlinePencilSquare className="text-[#0094AA]" />
    //           </IconButton>
    //         </Link>
    //       </div>
    //     );
    //   },
    // },
    {
      header: `Nr`,
      accessorKey: "incident_number",
      meta: {
        id: "incident_number",
        operators: ["=", "contains"],
      },
    },
  ];
  const [open, setOpen] = useState(false);

  const steps = [
    {
      title: " step1 ",
      subTitle: "subtitle ",
    },
    {
      title: "step 2  ",
      subTitle: "subtitle  ",
    },
    {
      title: "step3",
      subTitle: "subtitle ",
    },
    {
      title: "step4  ",
      subTitle: "subtitle ",
    },
    {
      title: "step5  ",
      subTitle: "subtitle ",
    },
  ];
  return (
    <>
      <PageHeading> Primary </PageHeading>
      <PageHeading variant="secondary"> Secondry </PageHeading>
      <div className="flex flex-wrap gap-10">
        <CustomButton variant="default">primary</CustomButton>
        <CustomButton variant="secondary">secondry</CustomButton>
        <CustomButton variant="outline">outlined</CustomButton>
        <CustomButton variant="destructive">destructive</CustomButton>
        <CustomButton variant="ghost">ghost</CustomButton>
        <CustomButton variant="link">link</CustomButton>
      </div>

      <div>
        <h1>Anywhere in your app!</h1>
        <Formik
          initialValues={{
            checkbox: false,
            test: "",
            group: "",
            autocomplet: "",
            date: "",
            textarea: "",
            select: "",
            fileupload: "",
          }}
          onSubmit={(values, { setSubmitting }) => {
            setTimeout(() => {
              setSubmitting(false);
            }, 400);
          }}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            isSubmitting,
          }) => (
            <form onSubmit={handleSubmit}>
              <Autocomplete
                name="autocomplet"
                options={frameworks}
                placeholder="Place Holder"
                label="test"
              />
              <CustomInput
                label="Group Activity "
                placeholder="Group Activity"
                className={" w-96"}
                required
                name="group"
              />
              <CustomInput
                label="test"
                placeholder="test"
                className={" w-96"}
                required
                name="test"
              />
              <DropZone name="test" clasName="!w-[400px]" />
              <DropZone name="test1" type="secondary" clasName="!w-[400px]" />
              <Label className="text-primary">thest text area</Label>
              <CoustomTextarea name="textarea" />
              {/* <CustomSelect options={frameworks} name="select" /> */}
              <CustomAccordion
                data={[{ title: "test", description: "test " }]}
              />
              <Switch />

              <CustomButton onClick={() => setOpen(true)}>dialog</CustomButton>
              {open && <CustomDialog title="hello">hello</CustomDialog>}
              <RichTextEditor name="hello" />
              <div className=" ">
                <Stepper steps={steps}>
                  {(currentStep) => {
                    switch (currentStep) {
                      case 0:
                        return <div>step 1</div>;
                      case 1:
                        return <div>step 2</div>;
                      case 2:
                        return <div>step 3</div>;
                      case 3:
                        return <div>step 4</div>;
                      case 4:
                        return <div>step 5</div>;
                      default:
                        return null;
                    }
                  }}
                </Stepper>

                <InputFile name="fileupload" />
                <DataTable columns={columns} url="" />
              </div>

              <CustomButton
                type="submit"
                disabled={isSubmitting}
                variant="default"
              >
                Submit
              </CustomButton>
            </form>
          )}
        </Formik>
      </div>
    </>
  );
};
