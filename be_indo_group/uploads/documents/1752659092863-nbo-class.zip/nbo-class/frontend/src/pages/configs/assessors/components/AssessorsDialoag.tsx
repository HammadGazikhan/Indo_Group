import { CustomDialog } from "@/components";
import CustomButton from "@/components/button";
import CustomInput from "@/components/inputs/custom-input";
import CustomSelect from "@/components/inputs/custom-select";
import { DialogFooter } from "@/components/ui/dialog";
import { Form, Formik } from "formik";
import React from "react";

const AssessorsDialoag = ({ setOpen }: { setOpen: any }) => {
  return (
    <div>
      <CustomDialog title="Add Assessor" className={"max-w-[1116px]"}>
        <Formik
          initialValues={{}}
          onSubmit={() => {
            setOpen(false);
          }}
        >
          <Form>
            <div className="flex gap-6 py-10  flex-wrap">
              <CustomInput
                name="name_of_the_assessor"
                label="Name of the Assessor"
                className="w-[335px]"
              ></CustomInput>
              <CustomInput
                name="assessor_email_id"
                label="Assessor Email ID"
                className="w-[335px]"
              ></CustomInput>
              <CustomSelect
                name="status"
                label="Status"
                className="w-[335px]"
                options={["enabled", "disabled"]}
                getOptionLabel={(item) => item?.name}
                getOptionValue={(item) => item?.name}
              ></CustomSelect>
              <CustomInput
                name="credentials"
                label="Credentials"
                className="w-[335px]"
              ></CustomInput>
            </div>
          </Form>
        </Formik>

        <DialogFooter className="py-4 px-6 border-t">
          <div className="flex justify-end items-center gap-5">
            <CustomButton variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </CustomButton>
            <CustomButton>Add</CustomButton>
          </div>
        </DialogFooter>
      </CustomDialog>
    </div>
  );
};

export default AssessorsDialoag;
