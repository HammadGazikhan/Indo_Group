import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import React, { useState } from "react";
import { GoUpload } from "react-icons/go";
import { IoMdAdd } from "react-icons/io";
import CompetenciesDialog from "./components/CompetenciesDialog";
import CustomTab from "@/components/custom-tab";

const CompetenciesPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Leadership Levels",
      accessorKey: "leadership-levels",
    },
    {
      header: "Competencies",
      accessorKey: "competencies",
    },

    {
      header: "Action",
      accessorKey: "Action",
    },
  ];
  const [open, setOpen] = useState(false);
  const [tabValue, setTabValue] = useState<string | number>(0);
  return (
    <div>
      <PageHeading>Competencies</PageHeading>
      <CustomTab
        setValue={setTabValue}
        tabs={[
          { label: "NBOL", value: 0 },
          { label: "Client", value: 1 },
        ]}
        value={tabValue}
        className="flex items-center"
      />
      {tabValue == 0 && (
        <Datagrid
          columns={columns}
          disableFilters
          extraButtons={
            <>
              <CustomButton variant="outline">
                <GoUpload />
                Upload
              </CustomButton>
              <CustomButton onClick={() => setOpen(true)}>
                <IoMdAdd />
                Add New
              </CustomButton>
            </>
          }
        />
      )}
      {tabValue == 1 && (
        <Datagrid
          columns={columns}
          disableFilters
          extraButtons={
            <>
              <CustomButton variant="outline">
                <GoUpload />
                Upload Competencies
              </CustomButton>
              <CustomButton onClick={() => setOpen(true)}>
                <IoMdAdd />
                Add New
              </CustomButton>
            </>
          }
        />
      )}
      {open && <CompetenciesDialog setOpen={setOpen} />}
    </div>
  );
};

export default CompetenciesPage;
