import React from "react";

const ClassConfigurationPage = () => {
  return <div>ClassConfigurationPage</div>;
};

export default ClassConfigurationPage;
