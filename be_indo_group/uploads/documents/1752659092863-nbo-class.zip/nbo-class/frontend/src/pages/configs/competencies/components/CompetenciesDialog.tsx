import { CustomDialog, Label, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomInput from "@/components/inputs/custom-input";
import { DialogFooter } from "@/components/ui/dialog";
import { MdInfoOutline } from "react-icons/md";
import { RxCross2 } from "react-icons/rx";

import { Field, FieldArray, Form, Formik } from "formik";
import React from "react";
import { IoMdAdd } from "react-icons/io";
import { Textarea } from "@/components/ui/textarea";

const CompetenciesDialog = ({ setOpen }: { setOpen: any }) => {
  return (
    <div>
      <CustomDialog title="Add New Competency" className={"max-w-[1116px]"}>
        <Formik
          initialValues={{ behaviors: [{ text: "" }] }}
          onSubmit={() => {
            setOpen(false);
          }}
        >
          {({ values }) => (
            <Form>
              <div className="flex gap-10 flex-col">
                <CustomInput
                  name="name_of_competencie"
                  label="Name of the Competencie"
                  className="w-[335px] h-[46px]"
                ></CustomInput>
                <PageHeading variant="secondary">
                  Expected Behaviors
                </PageHeading>
              </div>
              <FieldArray name="behaviors">
                {({ push, remove }) => (
                  <div className="space-y-4">
                    {values?.behaviors.map((_, index: any) => (
                      <div
                        key={index}
                        className="relative   rounded-lg  bg-white"
                      >
                        <Label className="text-sm font-medium">
                          Expected Behavior {index + 1}
                        </Label>
                        <div className="relative mt-2 flex items-center">
                          <div className="w-[90%]">
                            <Textarea
                              name={`behaviors[${index}].text`}
                              placeholder="Input text"
                              className="w-full p-2  !rounded-[5px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                          <div className=" ml-5 flex space-x-2">
                            {index === values.behaviors.length - 1 && (
                              <IoMdAdd
                                size={20}
                                className="text-green-500 cursor-pointer hover:text-green-700"
                                onClick={() => push({ text: "" })}
                              />
                            )}
                            <RxCross2
                              size={20}
                              className="text-red-500 cursor-pointer hover:text-red-700"
                              onClick={() => remove(index)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </FieldArray>
            </Form>
          )}
        </Formik>

        <DialogFooter className="py-4 px-6 border-t">
          <div className="flex justify-end items-center gap-5">
            <CustomButton variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </CustomButton>
            <CustomButton>Add</CustomButton>
          </div>
        </DialogFooter>
      </CustomDialog>
    </div>
  );
};

export default CompetenciesDialog;
