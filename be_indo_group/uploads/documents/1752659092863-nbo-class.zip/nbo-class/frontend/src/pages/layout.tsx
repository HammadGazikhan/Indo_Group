import { useState, useEffect } from "react";
import { AppSidebar, BreadcrumbBar } from "@/components";
import AppBar from "@/components/app-bar";
import { SidebarProvider } from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Layout({ children }: { children: React.ReactNode }) {
  const isMobile = useIsMobile();

  return (
    <div className="flex flex-col ">
      <AppBar />
      <SidebarProvider>
        <AppSidebar />
        <BreadcrumbBar />
        <main
          className={`flex-1 py-6 px-7 fixed ${
            isMobile ? "w-full" : "w-[calc(100vw_-_319px)] left-[319px]"
          } mt-[72px] h-[calc(100vh_-_132px)] overflow-auto`}
        >
          {children}
        </main>
      </SidebarProvider>
    </div>
  );
}
