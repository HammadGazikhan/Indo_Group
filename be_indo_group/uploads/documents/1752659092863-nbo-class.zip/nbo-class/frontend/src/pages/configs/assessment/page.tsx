import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import React from "react";
import { GoUpload } from "react-icons/go";

const AssessmentConfigPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Assessments",
      accessorKey: "assessments",
    },
    {
      header: "Scenario Added",
      accessorKey: "scenario_added",
    },
  ];
  return (
    <div>
      <PageHeading>Assessment</PageHeading>
      <div className="flex gap-10 mb-10">
        <CustomSelect
          name=""
          className="w-[494.33px] h-[48px]"
          label="Select Client"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        />
        <CustomSelect
          name=""
          className="w-[494.33px] h-[48px]"
          label="Select Project Name"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        />
      </div>
      <Datagrid
        columns={columns}
        url="https://dog.ceo/api/breeds/image/random"
        extraButtons={
          <>
            <CustomButton variant="outline">
              <GoUpload />
              Upload Assessment
            </CustomButton>
            <CustomButton variant="default">
              <Plus />
              Add Scenario
            </CustomButton>
          </>
        }
      ></Datagrid>
    </div>
  );
};

export default AssessmentConfigPage;
