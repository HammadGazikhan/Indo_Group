import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import React, { useState } from "react";
import AssessorsDialoag from "./components/AssessorsDialoag";

const AssessorsPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Assessor Name",
      accessorKey: "assessor_name",
    },
    {
      header: "Assessor Email Id",
      accessorKey: "assessor_email_id",
    },
    {
      header: "Credentials",
      accessorKey: "credentials",
    },

    {
      header: "Action",
      accessorKey: "Action",
    },
    {
      header: "Status",
      accessorKey: "status",
    },
  ];
  const [open, setOpen] = useState(false);
  return (
    <div>
      <PageHeading>Assessors</PageHeading>
      <Datagrid
        columns={columns}
        url="https://dog.ceo/api/breeds/image/random"
        extraButtons={
          <>
            <CustomButton variant="default" onClick={() => setOpen(true)}>
              <Plus />
              Add New
            </CustomButton>
          </>
        }
      ></Datagrid>
      {open && <AssessorsDialoag setOpen={setOpen} />}
    </div>
  );
};

export default AssessorsPage;
