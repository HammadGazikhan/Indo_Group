import { CustomDialog, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import { DropZone } from "@/components/inputs";
import { DialogFooter } from "@/components/ui/dialog";
import { Form, Formik } from "formik";
import React, { useState } from "react";
import SuccessDialog from "./SuccessDialog";

const UploadParticipantsListDialog = ({
  setOpenUploadList,
}: {
  setOpenUploadList: any;
}) => {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <CustomDialog title="Participants" className={"max-w-[1116px]"}>
        <PageHeading variant="secondary">Upload Participants List</PageHeading>
        <Formik
          initialValues={{}}
          onSubmit={() => {
            setOpenUploadList(false);
          }}
        >
          <Form>
            <div className="flex pb-10">
              <div className="w-1/2 flex flex-col pl-8 ">
                <DropZone
                  name="upload_particapents_list"
                  clasName="w-[478px]"
                />
              </div>
              <div className="w-1/2 px-8 flex flex-col items-center ">
                <div className="w-[478px]">
                  <h2 className="text-sm font-normal mb-6">
                    Steps to Upload Document
                  </h2>
                  <div className="bg-[#F5F5F5] rounded-[5px] px-10 py-6">
                    <ul>
                      <li className="list-disc">
                        The data can be uploaded only if proper template is used
                      </li>
                      <li className="list-disc">Lorem Ipsum</li>
                      <li className="list-disc">Lorem Ipsum</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </Form>
        </Formik>

        <DialogFooter className="py-4 px-6 border-t">
          <div className="flex justify-end items-center gap-5">
            <CustomButton
              variant="outline"
              onClick={() => setOpenUploadList(false)}
            >
              Cancel
            </CustomButton>
            <CustomButton variant="outline">Download Template</CustomButton>
            <CustomButton
              onClick={() => {
                setOpen(true);
              }}
            >
              Save
            </CustomButton>
          </div>
        </DialogFooter>
      </CustomDialog>
      {open && <SuccessDialog setOpen={setOpen} />}
    </div>
  );
};

export default UploadParticipantsListDialog;
