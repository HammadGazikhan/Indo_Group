import { CustomDialog, Label, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomInput from "@/components/inputs/custom-input";
import { DialogFooter } from "@/components/ui/dialog";
import { axios } from "@/config/axios";
import { queryClient } from "@/config/query-client";
import { useQuery } from "@/hooks/useQuerry";
import { useMutation } from "@tanstack/react-query";
import { FieldArray, Form, Formik } from "formik";
import React, { useEffect, useState } from "react";
import { IoMdAdd } from "react-icons/io";
import { RxCross2 } from "react-icons/rx";
import { toast } from "sonner";

const ClientConfigDialog = ({
  handleClose,
  id,
}: {
  handleClose: any;
  id?: any;
}) => {
  const { mutate, isPending } = useMutation({
    mutationFn: (data) =>
      id ? axios.put(`/client/${id}`, data) : axios.post("/client", data),
    onSuccess(data) {
      toast.success(data.data.msg || "Successfull");
      queryClient.refetchQueries({
        queryKey: [`/client`],
      });
    },
  });

  const { data: SingleClientData } = useQuery<any>({
    queryKey: [`/client/${id}`],
    select: (data: any) => data?.data?.row,
    enabled: !!id,
  });

  const [initialValues, setInitialValues] = useState({
    clientName: "",
    projectName: "",
    contactPersons: [{ name: "", email: "", department: "", mobile: "" }],
  });

  useEffect(() => {
    if (SingleClientData) {
      setInitialValues({
        clientName: SingleClientData?.clientName || "",
        projectName: SingleClientData?.projects?.[0]?.projectName || "",
        contactPersons: SingleClientData?.contactPersons?.map(
          (person: any) => ({
            name: person.name || "",
            email: person.email || "",
            department: person.department || "",
            mobile: person.mobile || "",
          })
        ) || [{ name: "", email: "", department: "", mobile: "" }],
      });
    }
  }, [SingleClientData]);
  return (
    <CustomDialog title="Add Client" className="max-w-[1116px] ">
      <Formik
        initialValues={initialValues}
        enableReinitialize
        onSubmit={(values: any) => {
          mutate({ ...values });
          handleClose();
        }}
      >
        {({ values, handleSubmit }) => (
          <Form>
            <div className="flex flex-col gap-10">
              {/* Client Name & Project Name */}
              <div className="flex gap-5">
                <CustomInput
                  name="clientName"
                  label="Client Name"
                  className="w-[335px]"
                />
                <CustomInput
                  name="projectName"
                  label="Project Name"
                  className="w-[335px]"
                />
              </div>
              <div>
                <PageHeading variant="secondary">
                  Client Contact Person
                </PageHeading>

                <FieldArray name="contactPersons">
                  {({ push, remove }) => (
                    <div className=" ">
                      {values.contactPersons.map((_: any, index: any) => (
                        <div
                          key={index}
                          className="relative rounded-lg bg-white  border-t-2"
                        >
                          <div className="relative mt-2 flex items-center py-10">
                            <div className="w-full flex flex-wrap gap-5">
                              <div>
                                <Label className="text-sm font-medium">
                                  Name
                                </Label>
                                <CustomInput
                                  name={`contactPersons[${index}].name`}
                                  placeholder="Enter name"
                                  className="w-[330px] p-2 !rounded-[5px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                              </div>
                              <div>
                                <Label className="text-sm font-medium">
                                  Email ID
                                </Label>
                                <CustomInput
                                  name={`contactPersons[${index}].email`}
                                  placeholder="Enter email"
                                  className="w-[330px] p-2 !rounded-[5px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                              </div>
                              <div>
                                <Label className="text-sm font-medium">
                                  Mobile Number
                                </Label>
                                <CustomInput
                                  name={`contactPersons[${index}].mobile`}
                                  placeholder="Enter mobile number"
                                  className="w-[330px] p-2 !rounded-[5px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                              </div>
                              <div className="flex items-center">
                                <div>
                                  <Label className="text-sm font-medium">
                                    Department
                                  </Label>
                                  <CustomInput
                                    name={`contactPersons[${index}].department`}
                                    placeholder="Enter department"
                                    className="w-[330px] p-2 !rounded-[5px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </div>
                                <div className="ml-5 mt-5 flex space-x-2">
                                  {index ===
                                    values.contactPersons.length - 1 && (
                                    <IoMdAdd
                                      size={20}
                                      className="text-green-500 cursor-pointer hover:text-green-700"
                                      onClick={() =>
                                        push({
                                          name: "",
                                          email: "",
                                          department: "",
                                          mobile: "",
                                        })
                                      }
                                    />
                                  )}
                                  {values.contactPersons.length > 1 && (
                                    <RxCross2
                                      size={20}
                                      className="text-red-500 cursor-pointer hover:text-red-700"
                                      onClick={() => remove(index)}
                                    />
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </FieldArray>
              </div>

              <DialogFooter className="py-4 px-6 border-t">
                <div className="flex justify-end items-center gap-5">
                  <CustomButton
                    variant="outline"
                    onClick={() => handleClose(false)}
                  >
                    Cancel
                  </CustomButton>
                  <CustomButton
                    type="submit"
                    disabled={isPending}
                    onClick={() => handleSubmit()}
                  >
                    Add
                  </CustomButton>
                </div>
              </DialogFooter>
            </div>
          </Form>
        )}
      </Formik>
    </CustomDialog>
  );
};

export default ClientConfigDialog;
