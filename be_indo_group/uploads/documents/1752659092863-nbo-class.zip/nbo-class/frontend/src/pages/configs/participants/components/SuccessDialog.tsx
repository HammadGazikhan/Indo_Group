import { CustomDialog } from "@/components";
import React from "react";

const SuccessDialog = ({ setOpen }: { setOpen: any }) => {
  return (
    <div>
      <CustomDialog
        title={
          <span className="flex items-center gap-3 text-[#155EEF]">
            <img src="/icons/Checkmark.svg"></img>Uploaded Successfully
          </span>
        }
        onClose={() => {
          setOpen(false);
        }}
        className={"max-w-[580px] "}
      >
        <div className="py-8">
          <h2 className="text-[#5F6D7E] pb-8">
            "Great job! Your file has been uploaded successfully and is ready to
            go!"
          </h2>
        </div>
      </CustomDialog>
    </div>
  );
};

export default SuccessDialog;
