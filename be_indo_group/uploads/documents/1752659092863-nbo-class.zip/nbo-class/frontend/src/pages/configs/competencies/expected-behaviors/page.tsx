import { PageHeading } from "@/components";
import React from "react";

const ExpectedBehaviorsPage = () => {
  const headers = [
    "Strategic Vision and Insight",
    "Business Acumen and Financial Stewardship",
    "Innovation & Transformation Leadership",
    "Inspirational Leadership and Decision-Making",
    "Collaborative Influence and Stakeholder Engagement",
    "Talent Development and Inclusion",
  ];

  const rows = Array(6).fill(
    Array(headers.length).fill(
      "The majority of our global interviews take place in line."
    )
  );
  return (
    <div>
      <PageHeading>Expected Behaviors</PageHeading>
      <div className="overflow-x-auto p-4">
        <table className="min-w-full ">
          <thead>
            <tr className="bg-[#EFF4FF]">
              <th
                colSpan={headers.length}
                className=" p-4 h-[60px] text-center text-base  font-medium text-[#5F6D7E]"
              >
                Leading The Organization
              </th>
            </tr>
            <tr className="bg-[#EFF4FF]">
              {headers.map((header, index) => (
                <th
                  key={index}
                  className="border border-[#DAE0E6] h-[49px] p-3 text-left text-[13px] font-normal text-[#49556D]"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr key={rowIndex} className="">
                {row.map((cell: any, cellIndex: any) => (
                  <td
                    key={cellIndex}
                    className="border border-[#DAE0E6] p-3 h-[55px] text-[12px] text-[#5F6D7E]"
                  >
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExpectedBehaviorsPage;
