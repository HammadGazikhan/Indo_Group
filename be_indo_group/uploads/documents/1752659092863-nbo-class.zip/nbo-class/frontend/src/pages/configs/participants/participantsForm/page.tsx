import { ButtonFooter, PageHeading } from "@/components";
import CustomButton from "@/components/button";
import { Autocomplete, DatePicker } from "@/components/inputs";
import CustomInput from "@/components/inputs/custom-input";
import CustomSelect from "@/components/inputs/custom-select";
import { axios } from "@/config/axios";
import { queryClient } from "@/config/query-client";
import { useQuery } from "@/hooks/useQuerry";
import { useMutation } from "@tanstack/react-query";
import { Form, Formik } from "formik";
import React, { useState } from "react";
import { Link, redirect, useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner";

const ParticipantsForm = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const clientData = state?.ClientData ?? [];

  const [clientId, setClientId] = useState<string | undefined>("");

  const { mutate, isPending } = useMutation({
    mutationFn: (data: any) => axios.post(`/participant/${clientId}`, data),
    onSuccess: (data) => {
      toast.success(data.data.msg || "Successfully submitted!");
      queryClient.invalidateQueries({ queryKey: [`/client`] });
    },
  });

  return (
    <div>
      <PageHeading>Add New Participants</PageHeading>
      <div className="mt-10">
        <Formik
          initialValues={{
            clientId: "",
            participantName: "",
            email: "",
            jobGrade: "",
            perf1: "",
            perf2: "",
            perf3: "",
            department: "",
            division: "",
            dateOfJoining: "",
            age: 0,
          }}
          onSubmit={(values) => {
            mutate(
              { ...values },
              {
                onSuccess: () => {
                  navigate(-1);
                },
              }
            );
          }}
        >
          {({ values, handleSubmit }) => (
            <>
              {console.log(values, "<------------ vlaues")}
              <Form onSubmit={handleSubmit}>
                <div className="flex flex-col gap-6">
                  <div className="flex gap-6">
                    <CustomSelect
                      key={values.clientId}
                      name="clientId"
                      label="Client Name"
                      className="w-[494px]"
                      options={clientData}
                      getOptionLabel={(item: any) => item?.clientName}
                      getOptionValue={(item: any) => item?.id}
                      onChange={(item) => {
                        setClientId(item?.id);
                        console.log(item);
                      }}
                    />
                    <Autocomplete
                      name="project_name"
                      label="Project Name"
                      className="w-[494px]"
                    />
                  </div>
                  <div className="flex flex-wrap gap-6">
                    <CustomInput
                      name="participantName"
                      label="Participant Name"
                      className="w-[494px]"
                    />
                    <CustomInput
                      name="email"
                      label="Email ID"
                      type="email"
                      className="w-[494px]"
                    />
                    <CustomInput
                      label="Job Grade"
                      name="jobGrade"
                      className="w-[494px]"
                    />
                    <CustomInput
                      name="perf1"
                      label="Performance Last Year"
                      className="w-[494px]"
                    />
                    <CustomInput
                      name="perf2"
                      label="Performance Two Years Before"
                      className="w-[494px]"
                    />
                    <CustomInput
                      name="perf3"
                      label="Performance Three Years Before"
                      className="w-[494px]"
                    />
                    <CustomInput
                      label="Department"
                      name="department"
                      className="w-[494px]"
                    />
                    <CustomInput
                      label="Division"
                      name="division"
                      className="w-[494px]"
                    />
                    <DatePicker
                      name="dateOfJoining"
                      label="Date"
                      className="w-[494px]"
                    />
                    <CustomInput
                      name="age"
                      label="Age"
                      className="w-[494px]"
                      type="number"
                    />
                  </div>
                </div>
                <ButtonFooter>
                  <div className="flex gap-4 justify-end">
                    <Link to={"/participants-config"}>
                      <CustomButton variant="outline">Cancel</CustomButton>
                    </Link>
                    <CustomButton
                      type="submit"
                      onClick={() => handleSubmit()}
                      disabled={isPending}
                    >
                      Save
                    </CustomButton>
                  </div>
                </ButtonFooter>
              </Form>
            </>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default ParticipantsForm;
