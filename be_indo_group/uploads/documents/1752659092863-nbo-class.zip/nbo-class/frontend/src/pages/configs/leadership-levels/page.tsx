import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus, Upload } from "lucide-react";
import React, { useState } from "react";
import LinkDialog from "./components/LinkDialog";
import { TbPlugConnected } from "react-icons/tb";

const LeadershipLevelsPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Client Role Levels",
      accessorKey: "client_role_name",
    },
    {
      header: "Linked To NBOL Leadership Levels",
      accessorKey: "linked_to_nbol_leadership_levels",
    },
    {
      header: "Actions",
      accessorKey: "actions",
    },
  ];
  const [open, setOpen] = useState(false);
  return (
    <div>
      <PageHeading>Leadership Levels</PageHeading>
      <div className="flex gap-10 mb-10">
        <CustomSelect
          name=""
          className="w-[494.33px] h-[48px]"
          label="Select Client"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        />
        <CustomSelect
          name=""
          className="w-[494.33px] h-[48px]"
          label="Select Project Name"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        />
      </div>
      <Datagrid
        columns={columns}
        url="https://dog.ceo/api/breeds/image/random"
        extraButtons={
          <>
            <CustomButton variant="outline" onClick={() => setOpen(true)}>
              <TbPlugConnected />
              Link Client Role Levels
            </CustomButton>
            <CustomButton variant="outline">
              <Upload />
              Upload Role Levels
            </CustomButton>
          </>
        }
      ></Datagrid>
      {open && <LinkDialog setOpen={setOpen} />}
    </div>
  );
};

export default LeadershipLevelsPage;
