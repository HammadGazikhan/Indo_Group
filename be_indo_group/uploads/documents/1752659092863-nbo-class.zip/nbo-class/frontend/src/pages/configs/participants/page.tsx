import { PageHeading } from "@/components";
import CustomButton from "@/components/button";
import CustomSelect from "@/components/inputs/custom-select";
import { Datagrid } from "@/components/ui/datagrid/data-table-new";
import { ColumnDef } from "@tanstack/react-table";
import { Plus, Upload } from "lucide-react";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import UploadParticipantsListDialog from "./components/UploadParticipantsListDialog";
import { useQuery } from "@/hooks/useQuerry";
import moment from "moment";

const ParticipantsPage = () => {
  const columns: ColumnDef<any>[] = [
    {
      header: "Client Name",
      accessorKey: "clientName",
      cell({ row }: { row: any }) {
        return row.original?.client?.clientName || "";
      },
    },
    {
      header: "Full Name",
      accessorKey: "participantName",
    },
    {
      header: "Email ID",
      accessorKey: "email",
    },
    {
      header: "Performance Last Year",
      accessorKey: "perf1",
    },
    {
      header: "Performance 2 years Before",
      accessorKey: "perf2",
    },
    {
      header: "Performance 3 years before",
      accessorKey: "perf3",
    },
    {
      header: "Department",
      accessorKey: "department",
    },
    {
      header: "Division",
      accessorKey: "division",
    },
    {
      header: "Job Grade",
      accessorKey: "jobGrade",
    },
    {
      header: "Date of Joining",
      accessorKey: "dateOfJoining",
      cell({ row }: { row: any }) {
        return moment(row.original?.dateOfJoining).format("DD/MM/YYYY");
      },
    },
    {
      header: "Age",
      accessorKey: "age",
    },
  ];

  //------------- State Management ------------//
  const [openUploadList, setOpenUploadList] = useState(false);
  const [selectedClient, setSelectedClient] = useState<any>();

  //-------------- API CALL ---------------//
  const { data: ClientData } = useQuery<any>({
    queryKey: [`/client/getall-clients`],
    select: (data: any) => data?.data?.rows,
    enabled: true,
  });

  return (
    <div>
      <PageHeading>Participants</PageHeading>
      <div className="flex gap-10 mb-10">
        <CustomSelect
          name="client"
          className="w-[494.33px] h-[48px]"
          label="Select Client"
          options={ClientData}
          getOptionLabel={(item: any) => item?.clientName}
          getOptionValue={(item: any) => item}
          onChange={(item) => setSelectedClient(item)}
        />
        {/* <CustomSelect
          className="w-[494.33px] h-[48px]"
          label="Select Project Name"
          getOptionLabel={(item) => item?.name}
          getOptionValue={(item) => item?.name}
          options={[]}
        /> */}
      </div>
      {selectedClient && (
        <Datagrid
          columns={columns}
          url={`/participant/${selectedClient?.id}`}
          extraButtons={
            <>
              <CustomButton
                variant="outline"
                onClick={() => {
                  setOpenUploadList(true);
                }}
              >
                <Upload />
                Upload Participant List
              </CustomButton>
              <CustomButton variant="outline">
                <Upload />
                Export
              </CustomButton>
              <Link
                to={{ pathname: "participantsForm" }}
                state={{ ClientData }}
              >
                <CustomButton variant="default">
                  <Plus />
                  Add New
                </CustomButton>
              </Link>
            </>
          }
        ></Datagrid>
      )}
      {openUploadList && (
        <UploadParticipantsListDialog setOpenUploadList={setOpenUploadList} />
      )}
    </div>
  );
};

export default ParticipantsPage;
