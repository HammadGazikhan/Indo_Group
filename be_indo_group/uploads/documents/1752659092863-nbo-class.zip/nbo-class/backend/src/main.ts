import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import * as cookieParser from 'cookie-parser';
import { ConfigService } from '@nestjs/config';
import { CustomeExceptionsFilter } from './common/filters';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.use(cookieParser());
  app.enableCors();
  const configService = app.get(ConfigService);
  console.log(configService.get('DB_HOST'));
  app.setGlobalPrefix('api');
  
  // set Globle filters
  app.useGlobalFilters(new CustomeExceptionsFilter());

  await app.listen(process.env.PORT ?? 5000);
}
bootstrap();
