import { SequelizeModule } from '@nestjs/sequelize';
import { Contactperson } from '../Modules/client-contact-persons/contactPerson.model';
import { Roles } from '../Modules/client-roles-levels/role.model';
// import { Projects } from 'src/client_project/project.model';
import { Clients } from '../Modules/clients/clients.model';
import { Facilities } from '../Modules/facilities/facility.model';
import { Rooms } from '../Modules/facilities/rooms.model';
import { NbolLeadLevels } from '../Modules/nbol-leadershiplevels/leadLevel.model';
import { Participants } from '../Modules/participants/participants.model';

export const DatabaseModule = SequelizeModule.forRoot({
  dialect: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  username: process.env.DB_USERNAME || 'postgres',
  password: process.env.PASSWORD || 'admin123',
  database: process.env.DATABASE || 'NBOL',
  logging: console.log,
  models: [
    Clients,
    Contactperson,
    // Projects,
    Facilities,
    Rooms,
    Participants,
    NbolLeadLevels,
    Roles
  ],
  synchronize: true,
  autoLoadModels: true,
});
