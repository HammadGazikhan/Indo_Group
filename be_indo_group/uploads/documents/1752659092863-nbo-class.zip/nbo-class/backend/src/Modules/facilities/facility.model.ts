import {
  BelongsTo,
  Column,
  DataType,
  ForeignKey,
  HasMany,
  Model,
  Table,
} from 'sequelize-typescript';
// import { Projects } from 'src/client_project/project.model';
import { Rooms } from './rooms.model';
import { Clients } from '../clients/clients.model';

@Table({
  tableName: "facilities"
})
export class Facilities extends Model<Facilities> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  facility_name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  address: string;

  @ForeignKey(() => Clients)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  client_id: number;

  // @ForeignKey(() => Projects)
  // @Column({
  //   type: DataType.INTEGER,
  //   allowNull: false,
  // })
  // projectId: number;

  @HasMany(() => Rooms, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  room: Rooms[];

  @BelongsTo(()=> Clients,{
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  client: Clients;

  // @BelongsTo(()=> Projects,{
  //   onDelete: 'CASCADE',
  //   onUpdate: 'CASCADE',
  // })
  // project: Projects;

}
