import { IsString, IsEmail, IsNotEmpty, IsPhoneNumber } from 'class-validator';
export class createContactPerson{
    @IsString()
    @IsNotEmpty()
    name: string;

    @IsEmail()
    @IsNotEmpty()
    email: string;

    @IsPhoneNumber()
    @IsNotEmpty()
    mobile: string;

    @IsString()
    @IsNotEmpty()   
    department: string;
} 