import { Injectable } from '@nestjs/common';
import { Roles } from './role.model';
import { InjectModel } from '@nestjs/sequelize';
import { Attributes, CreationAttributes } from 'sequelize';
import { NbolLeadLevels } from '../nbol-leadershiplevels/leadLevel.model';

@Injectable()
export class RoleService {
  constructor(
    @InjectModel(Roles)
    private roleModel: typeof Roles,
  ) {}

  // async createRoles(clientId: number, role: string, nbolId: number){
  //     const roles = await this.roleModel.create({
  //         clientId: clientId,
  //         role : role,
  //         nbolId: nbolId
  //     }as Roles)

  //     return{
  //         roles
  //     }
  // }
  // Adjust import as needed

  async createRoles(client_id: number, roles: string[], nbol_id: number) {
    const roleRecords: CreationAttributes<Roles>[] = roles.map(
      (role) =>
        ({
          client_id,
          role,
          nbol_id,
        }) as CreationAttributes<Roles>,
    );

    const createdRoles = await this.roleModel.bulkCreate(roleRecords, {
      validate: true,
    });

    return { createdRoles };
  }

  async getAllLevels(clientId: number, page:number, limit: number) {
    const offset = page*limit
    const levels = await this.roleModel.findAll({
      limit: limit,
      offset: offset,
      where: {
        client_id: clientId,
      },
      include: [
        {
          model: NbolLeadLevels,
          as: 'nbol', // it should match with model belongs to var
          required: true,
        },
      ],
    });
    const count =await this.roleModel.count({
      where:{
        client_id: clientId
      }
    })
    return {
      rows: levels,
      count,
    };
  }
}
