import { IsString } from "class-validator";

export class createNbolLevels{
    @IsString()
    leadership_level: string
}