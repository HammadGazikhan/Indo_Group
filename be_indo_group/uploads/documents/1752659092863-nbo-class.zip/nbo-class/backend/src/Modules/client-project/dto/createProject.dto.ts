import { IsString } from 'class-validator';

export class createProject {
  @IsString()
  project_name: string;
}
