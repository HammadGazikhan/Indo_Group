import { Module } from "@nestjs/common";
import { ClientController } from "./client.controller";
import { ClientService } from "./client.service";
import sequelize from "sequelize";
import { SequelizeModule } from "@nestjs/sequelize";
import { Clients } from "./clients.model";
import { Contactperson } from "../client-contact-persons/contactPerson.model";
// import { Projects } from "src/client_project/project.model";

@Module({
    imports: [
        SequelizeModule.forFeature([Clients, Contactperson,
            // Projects
        ], )
    ],
    controllers: [ClientController],
    providers: [ClientService],
    exports: [ClientService]

})
export class ClientModule {}