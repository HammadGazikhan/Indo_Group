import {
  BelongsTo,
  Column,
  DataType,
  ForeignKey,
  Model,
  Table,
} from 'sequelize-typescript';
import { Clients } from '../clients/clients.model';

@Table({
  tableName: 'contact_persons'
})
export class Contactperson extends Model<Contactperson> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  email: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  mobile: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  department: string;

  @ForeignKey(() => Clients)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  client_id: number;

  @BelongsTo(() => Clients)
  clients: Clients;
}
