import {
  Column,
  DataType,
  ForeignKey,
  HasOne,
  Model,
  Table,
  BelongsTo
} from 'sequelize-typescript';
import { Facilities } from './facility.model';
@Table({
  tableName: "rooms"
})
export class Rooms extends Model<Rooms> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  room: string;

  @ForeignKey(() => Facilities)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  facility_id: number;

  @BelongsTo(() => Facilities)
  facility: Facilities;
}
