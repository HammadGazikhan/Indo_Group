import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { nbolService } from './nbolLeadLevel.service';
import { createNbolLevels } from './dto/nbolDto';

@Controller('nbol-levels')
export class nbolController {
  constructor(private readonly nbolService: nbolService) {}

  @Post('/')
  async createNbol(@Body() createNbol: createNbolLevels) {
    return await this.nbolService.createNbol(createNbol);
  }

  @Get()
  async getAllLeadLevels(
    @Query('page') page: number = 0,
    @Query('limit') limit: number = 10,
  ) {
    return await this.nbolService.allLeadLevels(Number(page), Number(limit));
  }
}
