import {  BelongsTo, Column, DataType, ForeignKey, Model, Table } from "sequelize-typescript";
import { Clients } from "../clients/clients.model";
import { NbolLeadLevels } from "../nbol-leadershiplevels/leadLevel.model";

@Table({
    tableName: 'client_roles'
})
export class Roles extends Model<Roles>{
    @Column({
        type: DataType.STRING,
        allowNull: false
    })
    role: string

    @ForeignKey(()=> NbolLeadLevels)
    @Column({
        type: DataType.INTEGER,
        allowNull: false
    })
    nbol_id: number

    @ForeignKey(()=> Clients)
    @Column({
        type: DataType.INTEGER,
        allowNull: false
    })
    client_id: number

    @BelongsTo(()=>NbolLeadLevels)
    nbol: NbolLeadLevels

    @BelongsTo(()=> Clients)
    client: Clients
}