import { Body, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Clients } from './clients.model';
// import { Projects } from 'src/client_project/project.model';
import { Contactperson } from '../client-contact-persons/contactPerson.model';
import { Sequelize } from 'sequelize-typescript';
import { createClient } from './dto/createClient.dto';
import { CreationAttributes, NumberDataType, QueryTypes } from 'sequelize';

@Injectable()
export class ClientService {
  constructor(
    @InjectModel(Clients)
    private clientModel: typeof Clients,

    // @InjectModel(Projects)
    // private projectsModel: typeof Projects,

    @InjectModel(Contactperson)
    private contactPersonModel: typeof Contactperson,

    private sequelize: Sequelize,
  ) {}

  async createClient(clientData: createClient): Promise<Clients> {
    return await this.sequelize.transaction(async (transaction) => {
      const client = await this.clientModel.create(
        {
          client_name: clientData.client_name,
          project_name: clientData.project_name,
        } as Clients,
        { transaction },
      );

      // const project: CreationAttributes<Projects> = {
      //   projectName: clientData.projectName,
      //   clientId: client.id,
      // } as CreationAttributes<Projects>;

      // await this.projectsModel.create(project, { transaction });

      const contactPersons: CreationAttributes<Contactperson>[] =
        clientData.contact_persons.map(
          (person): CreationAttributes<Contactperson> =>
            ({
              name: person.name,
              email: person.email,
              mobile: person.mobile,
              department: person.department,
              client_id: client.id,
            }) as CreationAttributes<Contactperson>,
        );

      await this.contactPersonModel.bulkCreate(contactPersons, { transaction });

      return client;
    });
  }
  // ================================================================

  async getAllClients(page: number = 0, limit: number = 10): Promise<any> {
    const offset = page * limit;

    const record = await this.clientModel.count();
    console.log(record);

    const clients = await this.clientModel.findAll({
      offset: offset,
      limit: limit,
      attributes: ['client_name'],
      include: [
        // {
        //   model: this.projectsModel,
        //   as: 'projects',
        //   // attributes: ['projectName'],
        //   limit: 1,
        //   order: [['createdAt', 'DESC']],
        // },
        {
          model: this.contactPersonModel,
          as: 'contact_persons',
          attributes: ['department'],
          limit: 1,
          order: [['id', 'Asc']],
        },
      ],
    });
    return {
      rows: clients,
      count: record,
      page: page,
    };
  }

  async getAllClientsnoLimit(): Promise<any> {
    const record = await this.clientModel.count();

    const clients = await this.clientModel.findAll({

      attributes: ['client_name'],
      include: [
        // {
        //   model: this.projectsModel,
        //   as: 'projects',
        //   // attributes: ['project_name'],
        //   limit: 1,
        //   order: [['createdAt', 'DESC']],
        // },
        {
          model: this.contactPersonModel,
          as: 'contact_persons',
          attributes: ['department'],
          limit: 1,
          order: [['id', 'Asc']],
        },
      ],
    });
    return {
      rows: clients,
      records: record
    };
  }

  async getClient(clientId: number): Promise<any> {
    const client = await this.clientModel.findByPk(clientId, {
      attributes: ['client_name'],
      include: [
        // {
        //   model: this.projectsModel,
        //   as: 'projects',
        //   // attributes: ['projectName'],
        //   limit: 1,
        //   order: [['createdAt', 'DESC']],
        // },
        {
          model: this.contactPersonModel,
          as: 'contact_persons',
          // attributes: ['department'],
          // limit: 1,
          order: [['id', 'Asc']],
        },
      ],
    });
    return {
      row: client,
    };
  }

  async deleteClient(clientId: number): Promise<void> {
    const client = await this.clientModel.findByPk(clientId);
    if (client) {
      await client.destroy();
    } else {
      throw new HttpException('Client not found', HttpStatus.NOT_FOUND);
    }
  }

  //  =================================================================

  // async allClients(): Promise<any> {
  //   const client = await this.sequelize.query('SELECT * FROM Clients;', {
  //     type: QueryTypes.SELECT,
  //   });
  //   return {
  //     data: client
  //   }
  // }

  async allClients(): Promise<any> {
    const client = await this.clientModel.findAll();
    return {
      rows: client,
    };
  }

  // ================================================================

  async updateClient(
    client_id: number,
    updateData: Partial<createClient>,
  ): Promise<Clients> {
    return await this.sequelize.transaction(async (transaction) => {
      // Client
      const client = await this.clientModel.findByPk(client_id, { transaction });

      if (!client) {
        throw new HttpException('Client not found', HttpStatus.NOT_FOUND);
      }

      if (updateData.client_name) {
        client.client_name = updateData.client_name;
        await client.save({ transaction });
      }
// --------------------------------
      // project
      // if (updateData.projectName) {
      //   const project = await this.projectsModel.findOne({
      //     where: { clientId },
      //     transaction,
      //   });

      //   if (project) {
      //     project.projectName = updateData.projectName;
      //     await project.save({ transaction });
      //   } else {
      //     await this.projectsModel.create(
      //       {
      //         projectName: updateData.projectName,
      //         clientId,
      //       } as CreationAttributes<Projects>,
      //       { transaction },
      //     );
      //   }
      // }
//----------------------------------
      // contact person
      if (updateData.contact_persons && updateData.contact_persons.length > 0) {
        await this.contactPersonModel.destroy({
          where: { client_id },
          transaction,
        });

        const newContacts: CreationAttributes<Contactperson>[] =
          updateData.contact_persons.map(
            (person): CreationAttributes<Contactperson> =>
              ({
                name: person.name,
                email: person.email,
                mobile: person.mobile,
                department: person.department,
                client_id,
              }) as CreationAttributes<Contactperson>,
          );

        await this.contactPersonModel.bulkCreate(newContacts, { transaction });
      }

      return client;
    });
  }

  async getProjectsofClient(clientId: number){
    const project = await this.clientModel.findAll({
      where: {
        id:clientId
      },
      // include:[
      //   {
      //     model: Projects,
      //     as: 'projects',
      //     order: [['createdAt', 'Desc']]
      //   }
      // ]
    })
    return {
      row: project
    }
  }
}
