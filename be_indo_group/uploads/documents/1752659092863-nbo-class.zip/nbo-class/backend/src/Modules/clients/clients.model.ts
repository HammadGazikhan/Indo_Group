import {
  Column,
  DataType,
  HasMany,
  HasOne,
  Model,
  Table,
} from 'sequelize-typescript';
import { Contactperson } from '../client-contact-persons/contactPerson.model';
// import { Projects } from 'src/client_project/project.model';
import { Facilities } from '../facilities/facility.model';
import { Participants } from '../participants/participants.model';

@Table({
  tableName: 'clients'
})
export class Clients extends Model<Clients> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true,
  })
  client_name: string;

// updated
  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true,
  })
  project_name: string;

  // @HasMany(() => Projects, {
  //   onDelete: 'CASCADE',
  //   onUpdate: 'CASCADE',
  // })
  // projects: Projects[];

  @HasMany(()=> Facilities,{
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  facilities: Facilities[];

  @HasMany(() => Contactperson, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  contact_persons: Contactperson[];

  @HasMany(()=> Participants,{
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  participants: Participants[]

}
