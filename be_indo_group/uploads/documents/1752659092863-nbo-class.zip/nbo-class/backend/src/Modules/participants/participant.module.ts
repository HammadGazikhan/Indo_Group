import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { Participants } from "./participants.model";
import { participantController } from "./participant.controller";
import { participantService } from "./participant.service";

@Module({
    imports: [
        SequelizeModule.forFeature([Participants])
    ],
    controllers:[participantController],
    providers:[participantService],
    exports: [participantService]


})
export class ParticipantModule{} 