import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { Roles } from "./role.model";
import { RoelController } from "./role.controller";
import { RoleService } from "./role.service";

@Module({
    imports: [
        SequelizeModule.forFeature([Roles])
    ],
    controllers:[RoelController],
    providers: [RoleService],
    exports:[RoleService]
})
export class RoleModule{}