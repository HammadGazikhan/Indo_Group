import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { RoleService } from './role.service';
import { ResponseInterceptor } from 'src/common/interceptors';

@Controller('client-role')
export class RoelController {
  constructor(private readonly roleService: RoleService) {}

  @Post('/:id')
  @UseInterceptors(ResponseInterceptor)
  async createRole(
    @Param('id', ParseIntPipe) clientId: number,
    @Body('role') role: string[],
    @Body('nbolId') nbolId: number,
  ) {
    return await this.roleService.createRoles(clientId, role, nbolId);
  }

  @Get('/:id')
  async getAllLevels(
    @Param('id', ParseIntPipe) clientId: number,
    @Query('page') page: number = 0,
    @Query('limit') limit: number = 10,
  ) {
    return await this.roleService.getAllLevels(
      clientId,
      Number(page),
      Number(limit),
    );
  }
}
