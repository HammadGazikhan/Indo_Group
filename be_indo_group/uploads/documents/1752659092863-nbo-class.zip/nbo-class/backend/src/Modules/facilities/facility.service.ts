import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectConnection, InjectModel } from '@nestjs/sequelize';
import { Facilities } from './facility.model';
import { Rooms } from './rooms.model';
import { createFacility } from './dto/createFacility';
import { CreationAttributes } from 'sequelize';
import { Sequelize } from 'sequelize-typescript';

@Injectable()
export class facilityService {
  constructor(
    private sequelize: Sequelize,
    @InjectModel(Facilities)
    private facilityModel: typeof Facilities,
    @InjectModel(Rooms)
    private roomModel: typeof Rooms,
  ) {}

  async createFacility(
    clientId: number,
    facilityData: createFacility,
  ): Promise<Facilities> {
    if (!clientId) {
      throw new Error('Project ID is required but received null or undefined.');
    }
    return await this.sequelize.transaction(async (transaction) => {
      const facility = await this.facilityModel.create(
        {
          facility_name: facilityData.facility_name,
          address: facilityData.address,
          // projectId: projectId,
          client_id: clientId
        } as Facilities,
        { transaction },
      );

      const facilityRoom: CreationAttributes<Rooms>[] = facilityData.rooms.map(
        (froom): CreationAttributes<Rooms> =>
          ({
            room: froom.room,
            facility_id: facility.id,
          }) as CreationAttributes<Rooms>,
      );
      await this.roomModel.bulkCreate(facilityRoom, { transaction });
      return facility;
    });
  }

  async allFacilityProjec(
    // projectId: number,
    clientId: number,
    page: number = 0,
    limit: number = 10,
  ): Promise<any> {
    const offset = page * limit;

    // const record = await this.facilityModel.count();

    const facility = await this.facilityModel.findAll({
      where: {
        client_id: clientId,
      },
      offset: offset,
      limit: limit,
      attributes: ['id','facility_name', 'address'],
      include: [
        {
          model: Rooms,
          as: 'room',
          order: [['createdAt', 'DESC']],
        },
      ],
    });
    const record = await this.facilityModel.count({
      where:{
        client_id: clientId,
      }
    });

    return {
      rows: facility,
      count: record,
      page: page,
    };
  }

  async updateFacility(
    facility_id: number,
    updatefacility: Partial<createFacility>,
  ): Promise<Facilities> {

    return await this.sequelize.transaction(async (transaction) => {
      const facility = await this.facilityModel.findByPk(facility_id, {
        transaction,
      });
      if (!facility) {
        throw new HttpException('Client not found', HttpStatus.NOT_FOUND);
      }

      if (updatefacility.facility_name) {
        (facility.facility_name = updatefacility.facility_name),
          await facility.save({ transaction });
      }
      if (updatefacility.address) {
        (facility.address = updatefacility.address),
          await facility.save({ transaction });
      }
      //================= Rooms========
      if (updatefacility.rooms && updatefacility.rooms.length > 0) {
        await this.roomModel.destroy({
          where: { facility_id },
          transaction,
        });
        const facilityRoom: CreationAttributes<Rooms>[] =
          updatefacility.rooms.map(
            (froom): CreationAttributes<Rooms> =>
              ({
                room: froom.room,
                facility: facility.id,
              }) as CreationAttributes<Rooms>,
          );
        await this.roomModel.bulkCreate(facilityRoom, { transaction });
      }

      return facility;
    });
  }

  async deleteFacility(facilityId: number): Promise<any> {
    const facility = await this.facilityModel.findByPk(facilityId);
    if (facility) {
      await facility.destroy();
    } else {
      throw new HttpException('Facility not found', HttpStatus.NOT_FOUND);
    }
  }
}
