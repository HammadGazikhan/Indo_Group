import { Column, DataType, HasMany, Model, Table } from 'sequelize-typescript';
import { Roles } from '../client-roles-levels/role.model';

@Table({
  tableName: 'leadership_levels'
})
export class NbolLeadLevels extends Model<NbolLeadLevels> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  leadership_level: string;

  @HasMany(()=>Roles,{
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  roles: Roles[]

}
