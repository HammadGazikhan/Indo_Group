import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query } from '@nestjs/common';
import { ClientService } from './client.service';
import { createClient } from './dto/createClient.dto';


@Controller('client')
export class ClientController {
  constructor(private readonly clientService: ClientService) {}

  @Post('/')
  async createClient(@Body() createClientDto: createClient) {
    return await this.clientService.createClient(createClientDto);
  }

  @Get('/')
  async getAllClients(
    @Query('page') page: number = 0,
    @Query('limit') limit: number = 10,
  ) {
    return await this.clientService.getAllClients(Number(page), Number(limit));
  }
  
  @Get('getall-clients')
  async getall(){
    return await this.clientService.getAllClientsnoLimit()
  }

  @Get('client-project/:id')
  async clientProject(@Param('id')clientId: number,){
    return await this.clientService.getProjectsofClient(clientId)
  }
  
  @Put('/:id')
  async updateClient(
    @Param('id', ParseIntPipe) clientId: number,
    @Body() updateData: createClient,
  ) {
    return await this.clientService.updateClient(clientId, updateData);
  }

  @Get('/:id')
  async getClient(@Param("id", ParseIntPipe) clientId: number  ){
    return this.clientService.getClient(clientId)
  }

  @Get('all-clients')
  async allClients(){
    return await this.clientService.allClients()
  }

  @Delete('/:id')
  async deleteClient(@Param('id', ParseIntPipe) clientId: number){
    return this.clientService.deleteClient(clientId)
  }
}
