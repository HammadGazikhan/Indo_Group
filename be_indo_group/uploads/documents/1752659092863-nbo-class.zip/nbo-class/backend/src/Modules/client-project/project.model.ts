import {
  Column,
  DataType,
  ForeignKey,
  HasOne,
  Model,
  Table,
  BelongsTo,
  HasMany,
} from 'sequelize-typescript';
import { Clients } from '../clients/clients.model';
import { Facilities } from '../facilities/facility.model';
import { Participants } from '../participants/participants.model';

@Table({
    tableName: 'projects'
})
export class Projects extends Model<Projects> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true,
  })
  project_name: string;

  @ForeignKey(() => Clients)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  client_id: number;

  @BelongsTo(() => Clients, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  client: Clients;

  @HasMany(() => Facilities, {
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  })
  facility: Facilities[];

  // @HasMany(()=> Participants,{
  //   onDelete: 'CASCADE',
  //   onUpdate: 'CASCADE',
  // })
  // participants: Participants[];
}
