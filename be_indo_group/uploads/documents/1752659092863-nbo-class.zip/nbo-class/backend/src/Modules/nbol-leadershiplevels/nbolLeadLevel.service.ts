import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { NbolLeadLevels } from './leadLevel.model';
import { createNbolLevels } from './dto/nbolDto';

@Injectable()
export class nbolService {
  constructor(
    @InjectModel(NbolLeadLevels)
    private nbolModle: typeof NbolLeadLevels,
  ) {}

  async createNbol(createNbol: createNbolLevels): Promise<any> {
    const nbollevel = await this.nbolModle.create({
      leadership_level: createNbol.leadership_level,
    } as NbolLeadLevels);

    return {
      nbollevel,
    };
  }

  async allLeadLevels(page: number, limit: number): Promise<any> {
    const offset = page* limit;
    const leadLevels = await this.nbolModle.findAll({
      limit :limit,
      offset: offset
    });
    const count = await this.nbolModle.count()
    return {
        rows: leadLevels,
        count: count
    }
    
  }
}
