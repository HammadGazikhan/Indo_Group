import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { facilityService } from './facility.service';
import { createFacility } from './dto/createFacility';

@Controller('facility')
export class facilityController {
  constructor(private readonly facilityService: facilityService) {}

  @Post('/:id')
  async createFacility(
    @Param('id', ParseIntPipe) projectId: number,
    @Body() facilityData: createFacility,
  ) {
    return await this.facilityService.createFacility(projectId, facilityData);
  }

  @Put('/:id')
  async updateFacility(
    @Param('id', ParseIntPipe) facilityId: number,
    @Body() updateFacility: createFacility,
  ) {
    return await this.facilityService.updateFacility(
      facilityId,
      updateFacility,
    );
  }

  @Get('/:id')
  async allFacility(
    @Query('page') page: number = 0,
    @Query('limit') limit: number = 10,
    @Param('id', ParseIntPipe) clientId: number
  ) {
    return await this.facilityService.allFacilityProjec(clientId, Number(page), Number(limit));
  }

  @Delete('/:id')
  async deleteFacility(@Param('id',ParseIntPipe) facilityId: number){
    return await this.facilityService.deleteFacility(facilityId)
  }
}
