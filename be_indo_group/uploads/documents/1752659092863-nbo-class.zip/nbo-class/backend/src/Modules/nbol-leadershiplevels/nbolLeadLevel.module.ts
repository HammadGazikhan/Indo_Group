import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { NbolLeadLevels } from "./leadLevel.model";
import { nbolController } from "./nbolLeadLevel.controller";
import { nbolService } from "./nbolLeadLevel.service";

@Module({
    imports: [
        SequelizeModule.forFeature([NbolLeadLevels])
    ],
    controllers:[nbolController],
    providers:[nbolService],
    exports:[nbolService]

})
export class NbolModule{}