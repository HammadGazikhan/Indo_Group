export class createRoom{
    room: string
}