import { IsDate, IsEmail,  IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class createParticipants {
  @IsString()
  @IsNotEmpty()
  participant_name: string;

  @IsNotEmpty()
  @IsEmail()
  email: string
  
  @IsString()
  job_grade: string;

  @IsString()
  perf1: string;
  
  @IsString()
  perf2: string;
  
  
  @IsString()
  perf3: string;
  
  @IsString()
  department: string;
  
  @IsString()
  division: string;

  @IsDate()
  date_of_joining: Date;

  @IsNumber()
  age: number;

  @IsNumber()
  client_id: number;
}
