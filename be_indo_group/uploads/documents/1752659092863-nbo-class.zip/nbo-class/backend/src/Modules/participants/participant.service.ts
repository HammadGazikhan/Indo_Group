import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Participants } from './participants.model';
import { createParticipants } from './dto/createParticipants';
import { Clients } from '../clients/clients.model';
import { Model } from 'sequelize';
import { updateParticipants } from './dto/updateParticiapnts';

@Injectable()
export class participantService {
  constructor(
    @InjectModel(Participants)
    private participantModel: typeof Participants,
  ) {}

  async createParticipant(
    client_id: number,
    // projectId: number,
    createParticipant: createParticipants,
  ): Promise<any> {
    const participant = this.participantModel.create({
      participant_name: createParticipant.participant_name,
      email: createParticipant.email,
      job_grade: createParticipant.job_grade,
      perf1: createParticipant.perf1,
      perf2: createParticipant.perf2,
      perf3: createParticipant.perf3,
      department: createParticipant.department,
      division: createParticipant.division,
      date_of_joining: createParticipant.date_of_joining,
      age: createParticipant.age,
      client_id: createParticipant.client_id,
      // projectId: projectId,
      // clientId : clientId
    } as Participants);

    return participant;
  }

  async allParticipants(
    clientId: number,
    page: number = 0,
    limit: number = 10,
  ): Promise<any> {
    const offset = page * limit;
    const participant = await this.participantModel.findAll({
      where: {
        client_id: clientId,
      },
      offset: offset,
      limit: limit,
      include: [
        {
          model: Clients,
          as: 'client',
          attributes: ['id', 'client_name'],
        },
      ],
    });
    const count = await this.participantModel.count({
      where: {
        client_id: clientId,
      },
    });

    return {
      rows: participant,
      count: count,
      page: page,
    };
  }

  async updateParticipant(
    particiapntId: number,
    updateData: Partial<updateParticipants>,
  ): Promise<any> {
    const participant = await this.participantModel.findByPk(particiapntId);

    if (!participant) {
      throw new HttpException('Participant not found', HttpStatus.NOT_FOUND);
    }
    await participant.update({
      participant_name: updateData.participant_name,
      email: updateData.email,
      job_grade: updateData.job_grade,
      perf1: updateData.perf1,
      perf2: updateData.perf2,
      perf3: updateData.perf3,
      department: updateData.department,
      division: updateData.division,
      date_of_joining: updateData.date_of_joining,
      age: updateData.age,
    });

    return { message: 'Participant updated successfully', participant };
  }

  async deleteParticipant(participantId: number): Promise<any> {
    const part = await this.participantModel.findByPk(participantId);
    if (part) {
      await this.participantModel.destroy({ where: { id: participantId } });
    } else {
      throw new HttpException('Participant Not Found', HttpStatus.NOT_FOUND);
    }
    return {
      message: 'participant Deleted',
    };
  }
}
