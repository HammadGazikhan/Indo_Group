import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { Facilities } from "./facility.model";
import { Rooms } from "./rooms.model";
import { facilityService } from "./facility.service";
import { facilityController } from "./facility.controller";

@Module({
    imports:[
        SequelizeModule.forFeature([Facilities, Rooms])
    ],
    providers:[facilityService],
    controllers:[facilityController],
    exports: [facilityService]
})
export class FacilityModule{}