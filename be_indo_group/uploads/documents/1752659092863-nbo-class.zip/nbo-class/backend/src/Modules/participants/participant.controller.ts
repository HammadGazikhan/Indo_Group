import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { participantService } from './participant.service';
import { createParticipants } from './dto/createParticipants';
import { updateParticipants } from './dto/updateParticiapnts';

@Controller('participant')
export class participantController {
  constructor(private readonly participantService: participantService) {}

  @Post('/:id')
  async createParticipant(
    @Param('id', ParseIntPipe) client_id: number,
    // @Param('projectId', ParseIntPipe) projectId: number,
    @Body() createParticipant: createParticipants,
  ) {
    return await this.participantService.createParticipant(
      client_id,
      // projectId,
      createParticipant,
    );
  }

  @Get('/:id')
  async getAllParticipants(
    @Param('id', ParseIntPipe) projectId: number,
    @Query('page') page: number = 0,
    @Query('limit') limit: number = 10,
  ) {
    return await this.participantService.allParticipants(
      projectId,
      Number(page),
      Number(limit),
    );
  }

  @Put('update-particiapnt/:id')
  async updatepart(
    @Param('id', ParseIntPipe) particiapntId: number,
    @Body() body: updateParticipants,
  ) {
    return await this.participantService.updateParticipant(particiapntId, body);
  }

  @Delete('/:id')
  async deleteParticipant(@Param('id', ParseIntPipe) participantId: number) {
    return await this.participantService.deleteParticipant(participantId)
  }
}
