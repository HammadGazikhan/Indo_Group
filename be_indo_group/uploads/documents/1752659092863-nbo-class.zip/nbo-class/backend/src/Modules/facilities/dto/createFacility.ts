import { IsNotEmpty, IsString, IsArray, ValidateNested } from "class-validator"
import { createRoom } from "./createRoom"
import { Type } from "class-transformer"

export class createFacility{
    @IsString()
    @IsNotEmpty()
    facility_name: string

    @IsString()
    @IsNotEmpty()
    address: string

    @IsArray()
    @ValidateNested({each: true})
    @Type(()=> createRoom)
    rooms: createRoom[]
}