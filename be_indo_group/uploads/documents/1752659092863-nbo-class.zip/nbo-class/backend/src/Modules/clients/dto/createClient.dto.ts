import { IsString, IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import {createContactPerson} from 'src/Modules/client-contact-persons/dto/createContactPerson'

export class createClient {
  @IsString()
  client_name: string;

  @IsString()
  project_name: string;

  @IsArray()
  @ValidateNested({ each: true }) 
  @Type(() => createContactPerson)
  contact_persons: createContactPerson[];
}
