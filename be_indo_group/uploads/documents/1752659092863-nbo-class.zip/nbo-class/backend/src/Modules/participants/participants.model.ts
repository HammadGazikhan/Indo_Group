import { BelongsTo, Column, DataType, ForeignKey, Model, Table } from "sequelize-typescript";
// import { Projects } from "src/client_project/project.model";
import { Clients } from "../clients/clients.model";

@Table({
    tableName: 'participants'
})
export class Participants extends Model<Participants>{
    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    participant_name: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    email: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    job_grade: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    perf1: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    perf2: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    perf3: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    department: string 

    @Column({
        type:DataType.STRING,
        allowNull: false,
    })
    division: string 

    @Column({
        type:DataType.DATE,
        allowNull: false,
    })
    date_of_joining: Date 

    @Column({
        type:DataType.INTEGER,
        allowNull: false,
    })
    age: number 

    @ForeignKey(()=> Clients)
    @Column({
        type: DataType.INTEGER,
        allowNull: false
    })
    client_id: number

    // @ForeignKey(()=> Projects)
    // @Column({
    //     type: DataType.INTEGER,
    //     allowNull: false
    // })
    // project_id: number

    // @BelongsTo(()=> Projects)
    // project: Projects;

    @BelongsTo(()=> Clients)
    client: Clients;
}