import { Module } from '@nestjs/common';
import { DatabaseModule } from './database/database.provider';
import { ConfigModule } from '@nestjs/config';
import { ClientModule } from './Modules/clients/client.module';
import { FacilityModule } from './Modules/facilities/facility.module';
import { ParticipantModule } from './Modules/participants/participant.module';
import { NbolModule } from './Modules/nbol-leadershiplevels/nbolLeadLevel.module';
import { RoleModule } from './Modules/client-roles-levels/role.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { ResponseInterceptor } from './common/interceptors';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    DatabaseModule,
    ClientModule,
    FacilityModule,
    ParticipantModule,
    NbolModule,
    RoleModule,
  ],
  controllers: [],
  providers: [
    {
      provide: APP_INTERCEPTOR,
      useClass: ResponseInterceptor,
    },
  ],
})
export class AppModule {}
